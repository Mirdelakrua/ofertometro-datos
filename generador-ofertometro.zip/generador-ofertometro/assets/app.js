(function () {
  var idx = null, cargando = null;
  function norm(s) { return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function pesos(n) { return '$' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  function cargar() {
    if (idx) return Promise.resolve(idx);
    if (!cargando) cargando = fetch('/buscador.json').then(function (r) { return r.json(); }).then(function (d) {
      idx = d.map(function (x) { return { n: x[0], s: x[1], p: x[2], c: x[3], k: norm(x[0] + ' ' + x[3]) }; });
      return idx;
    });
    return cargando;
  }
  function buscar(q, max) {
    var t = norm(q).split(/\s+/).filter(Boolean);
    if (!t.length) return [];
    var r = [];
    for (var i = 0; i < idx.length; i++) {
      var ok = true;
      for (var j = 0; j < t.length; j++) if (idx[i].k.indexOf(t[j]) < 0) { ok = false; break; }
      if (ok) r.push(idx[i]);
      if (r.length >= (max || 400)) break;
    }
    return r;
  }
  function esc(s) { return s.replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function item(x) { return '<a href="/precio/' + x.s + '/"><span>' + esc(x.n) + '</span><small>desde ' + pesos(x.p) + '</small></a>'; }

  document.querySelectorAll('[data-buscador]').forEach(function (inp) {
    var form = inp.closest('form'), lista = form.querySelector('.sugerencias'), sel = -1;
    inp.addEventListener('focus', cargar, { once: true });
    inp.addEventListener('input', function () {
      var q = inp.value.trim();
      if (q.length < 2) { lista.hidden = true; return; }
      cargar().then(function () {
        var r = buscar(q, 8); sel = -1;
        lista.innerHTML = r.length ? r.map(function (x) { return '<li>' + item(x) + '</li>'; }).join('') : '<li><a href="/buscar/?q=' + encodeURIComponent(q) + '"><span>Ver resultados para “' + esc(q) + '”</span></a></li>';
        lista.hidden = false;
      });
    });
    inp.addEventListener('keydown', function (e) {
      var as = lista.querySelectorAll('a');
      if (lista.hidden || !as.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + as.length) % as.length;
        as.forEach(function (a, i) { a.setAttribute('aria-selected', i === sel ? 'true' : 'false'); });
      } else if (e.key === 'Enter' && sel >= 0) { e.preventDefault(); location.href = as[sel].href; }
      else if (e.key === 'Escape') lista.hidden = true;
    });
    document.addEventListener('click', function (e) { if (!form.contains(e.target)) lista.hidden = true; });
  });

  var res = document.getElementById('resultados');
  if (res) {
    var inp = document.querySelector('[data-buscador]');
    var q = new URLSearchParams(location.search).get('q') || '';
    function pintar(v) {
      if (v.trim().length < 2) { res.innerHTML = ''; return; }
      cargar().then(function () {
        var r = buscar(v, 200);
        res.innerHTML = '<p>' + r.length + ' producto' + (r.length === 1 ? '' : 's') + ' para “' + esc(v) + '”</p><ul>' + r.map(function (x) { return '<li>' + item(x) + '</li>'; }).join('') + '</ul>';
      });
    }
    if (inp) { inp.value = q; inp.addEventListener('input', function () { pintar(inp.value); }); }
    pintar(q);
  }
})();

/* Filtro por provincia y ciudad: guarda la elección y reordena las comparativas de la página */
(function () {
  var nodo = document.getElementById('ofe-comun'), sel = document.querySelector('[data-sel-prov]');
  if (!nodo || !sel) return;
  var C = JSON.parse(nodo.textContent), barra = document.querySelector('[data-barra-prov]'), fija = barra.getAttribute('data-fija') || '', ir = barra.hasAttribute('data-ir');
  var selC = barra.querySelector('[data-sel-ciudad]'), nota = document.querySelector('[data-bp-nota]'), notaOrig = nota.innerHTML;
  var F = document.getElementById('ofe-ficha'); F = F ? JSON.parse(F.textContent) : null;
  function pesos(n) { return '$' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function pnom(pv) { return C.prov[pv] ? C.prov[pv][0] : pv; }
  function lugar(pv, ci) { return ci ? ci : (pv === 'AR-C' ? 'la Ciudad de Buenos Aires' : pnom(pv)); }
  function cad(sl, link) {
    var c = C.cad[sl] || [sl, '', ''], img = c[1] ? '<img class="avatar" src="' + c[1] + '" alt="Logo de ' + esc(c[0]) + '" title="' + esc(c[0]) + '" width="28" height="28">' : '';
    return '<span class="entidad">' + img + ' ' + (link && c[2] ? '<a href="' + c[2] + '">' + esc(c[0]) + '</a>' : esc(c[0])) + '</span>';
  }
  function frase(i) { var d = Math.round((i - 100) * 10) / 10; if (Math.abs(d) < 0.5) return 'en el promedio de la zona'; return (Math.abs(d) < 10 ? Math.abs(d).toFixed(1).replace('.', ',') : Math.abs(Math.round(d))) + '% ' + (d < 0 ? 'más barato' : 'más caro') + ' que el promedio'; }
  function leer(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function guardar(k, v) { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} }
  // Cadenas que tienen sucursales en la provincia (y en la ciudad, si se eligió)
  function permitidas(pv, ci) {
    var o = {};
    Object.keys(C.cad).forEach(function (k) {
      var c = C.cad[k];
      if (ci ? (c[4] && c[4][pv] && c[4][pv][ci]) : c[3].indexOf(pv) >= 0) o[k] = true;
    });
    return o;
  }
  var orig = new Map();
  function guardarOrig(el) { if (!orig.has(el)) orig.set(el, el.innerHTML); }
  function restaurar(el) { if (orig.has(el)) el.innerHTML = orig.get(el); }

  function podios(pv, ci, ok) {
    document.querySelectorAll('[data-podio-prov]').forEach(function (ol) {
      guardarOrig(ol);
      var extra = ol.nextElementSibling && ol.nextElementSibling.hasAttribute('data-podio-extra') ? ol.nextElementSibling : null;
      if (extra) extra.remove();
      if (!pv) { restaurar(ol); return; }
      var r = C.rank[pv] || {}, max = +ol.getAttribute('data-podio-prov') || 12, h = '';
      var ks = Object.keys(r).filter(function (k) { return ok[k]; }).slice(0, max);
      if (ks.length >= 2) {
        var vs = ks.map(function (k) { return r[k]; }), lo = Math.min.apply(0, vs), sp = Math.max(2, Math.max.apply(0, vs) - lo);
        ks.forEach(function (k, i) {
          h += '<li' + (i ? '' : ' class="gana"') + '><span class="po-n">' + (i + 1) + '</span><span class="po-cad">' + cad(k, true) + '</span><span class="po-barra"><i style="width:' + (18 + 82 * (r[k] - lo) / sp).toFixed(1) + '%"></i></span><span class="po-val">' + frase(r[k]) + '</span></li>';
        });
        ol.innerHTML = h;
      } else {
        var hay = Object.keys(ok);
        ol.innerHTML = '<li class="po-vacio">' + (hay.length ? 'En ' + esc(lugar(pv, ci)) + ' informan precios: ' + hay.map(function (k) { return C.cad[k][2] ? '<a href="' + C.cad[k][2] + '">' + esc(C.cad[k][0]) + '</a>' : esc(C.cad[k][0]); }).join(', ') + '. No alcanza para armar un ranking.' : 'Todavía no hay supermercados que informen precios en ' + esc(lugar(pv, ci)) + '.') + '</li>';
      }
      if (C.prov[pv] && C.prov[pv][1] && location.pathname !== C.prov[pv][1]) {
        var p = document.createElement('p'); p.setAttribute('data-podio-extra', ''); p.innerHTML = '<a href="' + C.prov[pv][1] + '">Ver el ranking completo de ' + esc(lugar(pv, '')) + ' →</a>';
        ol.after(p);
      }
    });
  }

  function ficha(pv, ci, ok) {
    if (!F) return;
    var filas = document.querySelectorAll('tr[data-cad]'); if (!filas.length) return;
    var tb = filas[0].parentNode, tabla = tb.closest('table'), cap = tabla.querySelector('caption'), tit = document.querySelector('[data-pv-titulo]');
    var et = document.querySelector('[data-etiqueta]'), cl = document.querySelectorAll('[data-clave] .clave-val, [data-clave] .clave-nota');
    guardarOrig(tb); if (cap) guardarOrig(cap); if (et) guardarOrig(et); cl.forEach(guardarOrig);
    restaurar(tb); if (cap) restaurar(cap); if (et) restaurar(et); cl.forEach(restaurar); if (tit) tit.textContent = '';
    if (!pv) return;
    var d = F[pv];
    if (!d) { if (tit) tit.textContent = ' (no lo encontramos en ' + lugar(pv, ci) + ')'; return; }
    var vis = [];
    tb.querySelectorAll('tr[data-cad]').forEach(function (tr) {
      var k = tr.getAttribute('data-cad'), td = tr.children; tr.classList.remove('destacada');
      if (!d[k] || !ok[k]) { tr.hidden = true; return; }
      td[1].innerHTML = '<strong>' + pesos(d[k][0]) + '</strong>'; td[2].innerHTML = '<span class="tenue">en ' + esc(pnom(pv)) + '</span>'; td[3].textContent = d[k][1];
      vis.push([d[k][0], tr]);
    });
    if (!vis.length) { restaurar(tb); if (tit) tit.textContent = ' (no lo encontramos en ' + lugar(pv, ci) + ')'; return; }
    vis.sort(function (a, b) { return a[0] - b[0]; }).forEach(function (x) { tb.appendChild(x[1]); });
    vis[0][1].classList.add('destacada');
    var k0 = vis[0][1].getAttribute('data-cad'), m = vis.length, ps = vis.map(function (x) { return x[0]; }), ult = vis[m - 1][1].getAttribute('data-cad');
    if (et) { et.querySelector('[data-et-top]').textContent = 'Mejor precio en ' + lugar(pv, ci); et.querySelector('.pg').innerHTML = '<span class="pg-s">$</span>' + pesos(ps[0]).slice(1); et.querySelector('[data-et-cad]').textContent = C.cad[k0] ? C.cad[k0][0] : k0; }
    var v = document.querySelectorAll('[data-clave] .clave-val'), n = document.querySelectorAll('[data-clave] .clave-nota');
    if (v.length >= 4) {
      var med = m % 2 ? ps[(m - 1) / 2] : (ps[m / 2 - 1] + ps[m / 2]) / 2;
      v[0].textContent = pesos(ps[0]); n[0].textContent = C.cad[k0][0];
      v[1].textContent = pesos(med); n[1].textContent = 'mediana en ' + lugar(pv, ci);
      v[2].textContent = pesos(ps[m - 1]); n[2].textContent = C.cad[ult] ? C.cad[ult][0] : ult;
      v[3].textContent = pesos(ps[m - 1] - ps[0]); n[3].textContent = Math.round((ps[m - 1] - ps[0]) / ps[0] * 100) + '% de diferencia';
    }
    if (tit) tit.textContent = ' de ' + lugar(pv, ci);
    if (cap) cap.textContent = 'Precio más común entre las sucursales de cada cadena en ' + pnom(pv) + (ci ? ' (cadenas con sucursal en ' + ci + ')' : '');
  }

  function listados(pv, ci, ok) {
    document.querySelectorAll('tr[data-pv-prod]').forEach(function (tr) {
      guardarOrig(tr); restaurar(tr); tr.classList.remove('sin-prov');
      if (!pv) return;
      var l = (JSON.parse(tr.getAttribute('data-pv-prod'))[pv] || []).filter(function (x) { return ok[x[0]]; }), td = tr.children;
      if (!l.length) { tr.classList.add('sin-prov'); for (var i = 1; i < 6; i++) td[i].innerHTML = i === 1 ? '<span class="tenue">no está en ' + esc(lugar(pv, ci)) + '</span>' : '<span class="tenue">—</span>'; return; }
      var ps = l.map(function (x) { return x[1]; }), m = ps.length, med = m % 2 ? ps[(m - 1) / 2] : (ps[m / 2 - 1] + ps[m / 2]) / 2;
      td[1].innerHTML = cad(l[0][0], false); td[2].innerHTML = '<strong>' + pesos(ps[0]) + '</strong>'; td[3].textContent = pesos(med); td[4].textContent = pesos(ps[m - 1]);
      td[5].innerHTML = m > 1 ? '<span class="dif">' + Math.round((ps[m - 1] - ps[0]) / ps[0] * 100) + '%</span>' : '<span class="tenue">una sola cadena</span>';
    });
    document.querySelectorAll('tbody').forEach(function (tb) { tb.querySelectorAll('tr.sin-prov').forEach(function (tr) { tb.appendChild(tr); }); });
  }

  // Rankings por categoría, ofertas y listas de cadenas: se ocultan las que no están en la zona
  function filtrarCadenas(pv, ok) {
    document.querySelectorAll('[data-cad-flt]').forEach(function (el) {
      if (el.closest('[data-podio-prov]')) return;
      el.hidden = !!pv && !ok[el.getAttribute('data-cad-flt')];
    });
    document.querySelectorAll('ol.podio:not([data-podio-prov])').forEach(function (ol) {
      var n = 0; ol.querySelectorAll('li').forEach(function (li) { if (!li.hidden) { n++; var x = li.querySelector('.po-n'); if (x) x.textContent = n; li.classList.toggle('gana', n === 1); } });
    });
  }

  function llenarCiudades(pv, ci) {
    var l = (pv && C.loc[pv]) || [];
    selC.innerHTML = '<option value="">Toda la provincia</option>' + l.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === ci ? ' selected' : '') + '>' + esc(x[0]) + ' (' + x[2] + (x[2] === 1 ? ' cadena' : ' cadenas') + ')</option>'; }).join('');
    selC.hidden = l.length < 2;
    if (selC.hidden) selC.value = '';
  }

  function aplicar(pv, ci) {
    var ok = pv ? permitidas(pv, ci) : {};
    nota.innerHTML = pv ? 'Mostrando los supermercados de <strong>' + esc(lugar(pv, ci)) + (ci ? ', ' + esc(pnom(pv)) : '') + '</strong>.' + (fija ? '' : ' <button type="button" class="bp-quitar" data-bp-quitar>Ver todo el país</button>') : notaOrig;
    barra.classList.toggle('activa', !!pv);
    podios(pv, ci, ok); ficha(pv, ci, ok); listados(pv, ci, ok); filtrarCadenas(pv, ok);
  }

  var pv = fija || leer('prov'); if (pv && !C.prov[pv]) pv = '';
  var ci = leer('ciudad'); if (!pv || !(C.loc[pv] || []).some(function (x) { return x[0] === ci; })) ci = '';
  if (fija) guardar('prov', fija);
  sel.value = pv; llenarCiudades(pv, ci); if (pv) aplicar(pv, ci);

  sel.addEventListener('change', function () {
    var v = sel.value; guardar('prov', v); guardar('ciudad', '');
    // En la portada y en la página de una provincia, elegir provincia lleva a su ranking
    if ((ir || fija) && v && C.prov[v] && C.prov[v][1]) { location.href = C.prov[v][1]; return; }
    if (fija && !v) { location.href = '/supermercado-mas-barato/'; return; }
    llenarCiudades(v, ''); aplicar(v, '');
  });
  selC.addEventListener('change', function () { guardar('ciudad', selC.value); aplicar(sel.value, selC.value); });
  barra.addEventListener('click', function (e) { if (e.target.hasAttribute('data-bp-quitar')) { sel.value = ''; guardar('prov', ''); guardar('ciudad', ''); llenarCiudades('', ''); aplicar('', ''); } });
})();
