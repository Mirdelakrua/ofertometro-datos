<?php
// Supermercado más barato (nacional y por provincia) y canasta.

function seccion_ranking($D)
{
    if (!$D['ok']['precios']) return;
    registrar('/supermercado-mas-barato/', 0, 'precios', function () use ($D) { return ranking_nacional($D); });
    registrar('/canasta-basica-supermercado/', 0, 'precios', function () use ($D) { return canasta($D); });
    foreach ($D['canasta']['provincias'] ?? [] as $pv => $fila) {
        if (count($fila) < 2) continue;
        registrar(path_prov($D, $pv), 0, 'precios', function () use ($D, $pv) { return ranking_provincia($D, $pv); });
    }
}

function ticket_canasta($D, $cad, $total, $max_items = 0)
{
    $items = $D['canasta']['items'];
    $h = '<div class="ticket"><div class="tk-cab"><strong>' . e(cadena_nombre($D, $cad)) . '</strong><span>Canasta Ofertómetro · ' . count($items) . ' productos</span></div><ul>';
    if ($max_items) {
        foreach (array_slice($items, 0, $max_items) as $sl) {
            $p = $D['productos'][$D['por_slug'][$sl]] ?? null;
            if (!$p) continue;
            $h .= '<li><span>' . e($p['nombre']) . '</span><b>' . (isset($p['cad'][$cad]) ? pesos($p['cad'][$cad]['p']) : '—') . '</b></li>';
        }
        $h .= '<li class="tk-mas"><span>… y ' . (count($items) - $max_items) . ' productos más</span><b></b></li>';
    }
    return $h . '</ul><div class="tk-total"><span>TOTAL</span><b>' . pesos($total) . '</b></div></div>';
}

function totales_canasta($D)
{
    $t = [];
    foreach ($D['canasta']['cadenas'] ?? [] as $c => $x) if (isset($D['ranking'][$c])) $t[$c] = $x['total'];
    asort($t);
    return $t;
}

function ranking_nacional($D)
{
    $t = totales_canasta($D);
    $g = array_key_first($D['ranking']);
    $fecha = fecha_datos($D);
    $c = '<p class="intro">Comparamos <strong>los mismos ' . num(count($D['productos'])) . ' productos</strong> en todas las cadenas para saber cuál es, de verdad, el supermercado más barato. '
        . 'Hoy gana <strong>' . e(cadena_nombre($D, $g)) . '</strong>: ' . e(frase_indice($D['ranking'][$g] / 100)) . '.</p>';
    $ind = [];
    foreach ($D['ranking'] as $cad => $v) $ind[$cad] = $v / 100;
    $c .= '<h2>Ranking de supermercados por precio</h2>' . barras_indice($D, $ind, 20, true)
        . '<p class="nota">Para cada producto calculamos cuánto cobra cada cadena respecto del precio típico del mercado, y tomamos la mediana. Así una cadena no gana sólo porque vende menos productos caros.</p>';
    if ($t) {
        $ct = array_key_first($t); $cc = array_key_last($t);
        $c .= '<h2>La misma canasta, en cada supermercado</h2><p>Llenamos el changuito con ' . count($D['canasta']['items']) . ' productos básicos de marcas líderes. En <strong>' . e(cadena_nombre($D, $ct)) . '</strong> cuesta '
            . pesos($t[$ct]) . ' y en ' . e(cadena_nombre($D, $cc)) . ' ' . pesos($t[$cc]) . ': <strong>' . pesos($t[$cc] - $t[$ct]) . ' de diferencia</strong>.</p><div class="tickets">';
        foreach (array_slice($t, 0, 3, true) as $cad => $tot) $c .= ticket_canasta($D, $cad, $tot);
        $c .= '</div><p>' . enlace('/canasta-basica-supermercado/', 'Ver la canasta completa, producto por producto') . '</p>';
    }
    // Por provincia
    $f = [];
    $provs = $D['canasta']['provincias'] ?? [];
    uksort($provs, function ($a, $b) use ($D) { return strcmp(prov_nombre($D, $a), prov_nombre($D, $b)); });
    foreach ($provs as $pv => $fila) {
        if (count($fila) < 2) continue;
        $k = array_keys($fila);
        $f[] = [enlace(path_prov($D, $pv), prov_nombre($D, $pv)), cadena_celda($D, $k[0], false), e(cadena_nombre($D, $k[1])), count($fila)];
    }
    if ($f) $c .= '<h2>Supermercado más barato en cada provincia</h2>' . tabla(['Provincia', 'El más barato', 'Segundo', 'Cadenas comparadas'], $f, [3]);
    $c .= enlaces_relacionados([['/ofertas/', 'Ofertas de supermercados de hoy'], ['/supermercados/', 'Todas las cadenas'], ['/precios/', 'Precios por categoría']]);
    $faqs = [['¿Cuál es el supermercado más barato de Argentina?', 'Según los precios del ' . e(fecha_larga($fecha, false)) . ', ' . e(cadena_nombre($D, $g)) . ' es el más barato comparando los mismos productos (' . e(frase_indice($D['ranking'][$g] / 100)) . '). El ranking cambia: lo recalculamos todos los días.'],
        ['¿De dónde salen los precios?', 'Del SEPA (Sistema Electrónico de Publicidad de Precios Argentinos), donde las cadenas grandes están obligadas a informar a diario los precios de cada sucursal. Es la base de Precios Claros.'],
        ['¿Por qué no aparece mi supermercado?', 'Sólo están obligadas a informar las cadenas grandes. Los supermercados chinos, almacenes y autoservicios de barrio no figuran en el SEPA.']];
    return ['title' => 'Supermercado más barato hoy: ranking de precios', 'h1' => '¿Cuál es el supermercado más barato hoy?',
        'desc' => 'Ranking de supermercados por precio: comparamos los mismos productos en Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás y más. Hoy gana ' . cadena_nombre($D, $g) . '.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'SEPA – Precios Claros', 'prov' => true];
}

function ranking_provincia($D, $pv)
{
    $nom = prov_nombre($D, $pv);
    $fila = $D['canasta']['provincias'][$pv];
    $g = array_key_first($fila);
    $en = $pv === 'AR-C' ? 'en la Ciudad de Buenos Aires' : 'en ' . $nom;
    $c = '<p class="intro">Comparamos los mismos productos en los supermercados que tienen sucursales ' . e($en) . '. El más barato hoy es <strong>' . e(cadena_nombre($D, $g)) . '</strong>.</p>';
    $ind = [];
    foreach ($fila as $cad => $v) $ind[$cad] = $v / 100;
    $c .= barras_indice_simple($D, $ind);
    // Productos: dónde conviene en la provincia
    $prods = [];
    foreach ($D['canasta']['items'] as $sl) {
        $p = $D['productos'][$D['por_slug'][$sl]] ?? null;
        if (!$p || empty($p['prov'][$pv])) continue;
        // La tabla muestra los precios de la provincia (el filtro por ciudad los recalcula en el navegador)
        $ps = array_column($p['prov'][$pv], 1);
        $q = $p;
        $q['cad'] = [];
        foreach ($p['prov'][$pv] as $x) $q['cad'][$x[0]] = ['p' => $x[1], 'n' => $x[2]];
        sort($ps);
        $q['min'] = $ps[0]; $q['max'] = end($ps); $q['med'] = $ps[intdiv(count($ps), 2)];
        $prods[] = $q;
    }
    if ($prods) $c .= '<h2>Dónde está más barato cada producto ' . e($en) . '</h2>' . tabla_productos($D, $prods);
    // Ciudades
    $locs = $D['meta']['localidades'][$pv] ?? [];
    if (count($locs) >= 2) {
        $c .= '<h2>Supermercados por ciudad</h2><p>Qué cadenas tienen sucursales en cada ciudad ' . e($pv === 'AR-C' ? 'de la Ciudad' : 'de ' . $nom) . '. Elegí tu ciudad arriba y la comparativa muestra solo esas cadenas.</p><div class="ciudades">';
        foreach ($locs as $l) {
            $cs = [];
            foreach ($D['cadenas'] as $cad => $x) if (!empty($x['loc'][$pv][$l[0]])) $cs[$cad] = $x['loc'][$pv][$l[0]];
            arsort($cs);
            $c .= '<section class="ciudad"><h3>' . e($l[0]) . '</h3><ul>';
            foreach ($cs as $cad => $n) $c .= '<li>' . (publicada(path_cadena($cad)) ? enlace(path_cadena($cad), cadena_nombre($D, $cad)) : e(cadena_nombre($D, $cad))) . ' <span class="tenue">' . $n . ' suc.</span></li>';
            $c .= '</ul></section>';
        }
        $c .= '</div>';
    }
    $sucs = [];
    foreach ($D['cadenas'] as $cad => $x) if (!empty($x['prov'][$pv])) $sucs[$cad] = $x['prov'][$pv];
    arsort($sucs);
    $fs = [];
    foreach ($sucs as $cad => $n) $fs[] = [cadena_celda($D, $cad, publicada(path_cadena($cad))), num($n), '_attr' => 'data-cad-flt="' . e($cad) . '"'];
    $c .= '<h2>Supermercados con sucursales ' . e($en) . '</h2>' . tabla(['Cadena', 'Sucursales'], $fs, [1]);
    $otras = [];
    foreach ($D['canasta']['provincias'] as $op => $ff) if ($op !== $pv && count($ff) >= 2) $otras[] = [path_prov($D, $op), 'Supermercado más barato en ' . prov_nombre($D, $op)];
    $c .= enlaces_relacionados(array_merge([['/supermercado-mas-barato/', 'Ranking nacional de supermercados']], array_slice($otras, 0, 10)));
    $faqs = [['¿Cuál es el supermercado más barato ' . $en . '?', 'Comparando los mismos productos, hoy el más barato ' . e($en) . ' es ' . e(cadena_nombre($D, $g)) . ' (' . e(frase_indice($fila[$g] / 100)) . ').']];
    return ['title' => titulo_corto('Supermercado más barato ' . $en . ' hoy', 'Supermercado más barato en ' . $nom), 'h1' => 'Supermercado más barato ' . $en,
        'desc' => '¿Qué supermercado es más barato ' . $en . '? Ranking de precios con los mismos productos en cada cadena. Hoy gana ' . cadena_nombre($D, $g) . '.',
        'migas' => [['Supermercado más barato', '/supermercado-mas-barato/']], 'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'SEPA – Precios Claros', 'prov' => $pv];
}

function barras_indice_simple($D, $ind)
{
    asort($ind);
    $GLOBALS['_rk_tmp'] = true;
    // barras_indice usa sólo cadenas del ranking nacional para el link; acá mostramos todas las de la provincia
    $lo = min($ind); $hi = max($ind); $span = max(0.02, $hi - $lo);
    $h = '<ol class="podio">';
    $k = 0;
    foreach ($ind as $c => $v) {
        $k++;
        $w = 18 + 82 * (($v - $lo) / $span);
        $h .= '<li data-cad-flt="' . e($c) . '"' . ($k === 1 ? ' class="gana"' : '') . '><span class="po-n">' . $k . '</span><span class="po-cad">' . cadena_celda($D, $c, publicada(path_cadena($c))) . '</span>'
            . '<span class="po-barra"><i style="width:' . round($w, 1) . '%"></i></span><span class="po-val">' . e(frase_indice($v)) . '</span></li>';
    }
    return $h . '</ol>';
}

function canasta($D)
{
    $t = totales_canasta($D);
    $items = $D['canasta']['items'];
    $cads = array_keys($t);
    $c = '<p class="intro">Una canasta de <strong>' . count($items) . ' productos de almacén, lácteos, limpieza e higiene</strong>, siempre de las mismas marcas y presentaciones, comprada en cada supermercado. '
        . 'Es la forma más directa de ver cuánto cambia el ticket según dónde comprás.</p>';
    if ($t) {
        $ct = array_key_first($t); $cc = array_key_last($t);
        $c .= datos_clave([['Más barata', pesos($t[$ct]), e(cadena_nombre($D, $ct))], ['Más cara', pesos($t[$cc]), e(cadena_nombre($D, $cc))], ['Diferencia', pesos($t[$cc] - $t[$ct]), pct_txt(($t[$cc] - $t[$ct]) / $t[$ct]) . ' más']]);
        $c .= '<div class="tickets">';
        foreach (array_slice($t, 0, 3, true) as $cad => $tot) $c .= ticket_canasta($D, $cad, $tot, 6);
        $c .= '</div>';
        $f = [];
        foreach ($t as $cad => $tot) {
            $x = $D['canasta']['cadenas'][$cad];
            $f[] = [cadena_celda($D, $cad), '<strong>' . pesos($tot) . '</strong>', '+' . pesos($tot - $t[$ct]), $x['imputados'] ? $x['imputados'] . ' estimado' . ($x['imputados'] > 1 ? 's' : '') : '<span class="tenue">completa</span>'];
        }
        $c .= '<h2>Cuánto cuesta la canasta en cada supermercado</h2>' . tabla(['Supermercado', 'Total', 'Contra el más barato', 'Productos'], $f, [1, 2], 0);
        $c .= '<p class="nota">Si a una cadena le falta algún producto, lo estimamos con el precio típico ajustado por qué tan cara es esa cadena, para comparar parejo.</p>';
    }
    // Detalle producto por producto
    $top = array_slice($cads, 0, 6);
    $f = [];
    foreach ($items as $sl) {
        $p = $D['productos'][$D['por_slug'][$sl]] ?? null;
        if (!$p) continue;
        $fila = [enlace(path_producto($p), $p['nombre'])];
        $min = min(array_map(function ($cd) use ($p) { return $p['cad'][$cd]['p'] ?? INF; }, $top));
        foreach ($top as $cd) {
            $v = $p['cad'][$cd]['p'] ?? null;
            $fila[] = $v === null ? '<span class="tenue">—</span>' : ($v == $min ? '<strong class="positivo">' . pesos($v) . '</strong>' : pesos($v));
        }
        $f[] = $fila;
    }
    $c .= '<h2>Producto por producto</h2>' . tabla(array_merge(['Producto'], array_map(function ($cd) use ($D) { return cadena_nombre($D, $cd); }, $top)), $f, range(1, count($top)), null, 'En verde, el precio más bajo de cada producto');
    // Evolución
    $series = $D['historial']['c'] ?? [];
    if ($t && !empty($series[array_key_first($t)]) && count($series[array_key_first($t)]) >= 7) {
        $s = $series[array_key_first($t)];
        ksort($s);
        $pts = [];
        foreach ($s as $fch => $v) $pts[] = [$fch, $v];
        $c .= '<h2>Evolución de la canasta</h2>' . grafico('canasta-' . array_key_first($t), svg_linea($pts, 'Canasta en ' . cadena_nombre($D, array_key_first($t)), 'Total de la canasta día por día', 'pesos'),
            'Gráfico de la evolución del precio de la canasta en ' . cadena_nombre($D, array_key_first($t)), 'Evolución de la canasta de supermercado');
    }
    $c .= enlaces_relacionados([['/supermercado-mas-barato/', 'Supermercado más barato hoy'], ['/ofertas/', 'Ofertas de supermercados'], ['https://tasometro.com.ar/inflacion/', 'Inflación mensual (Tasómetro)']]);
    $faqs = [['¿Qué incluye la canasta?', 'Leche, aceite, arroz, fideos, azúcar, yerba, harina, café, sal, puré de tomate, mayonesa, dulce de leche, manteca, yogur, queso crema, galletitas, gaseosa, agua, lavandina, detergente, jabón para ropa, papel higiénico, shampoo, jabón de tocador y pasta dental, de marcas líderes.'],
        ['¿Es la canasta básica del INDEC?', 'No. La Canasta Básica Total del INDEC mide el costo de vida de un hogar con cantidades por persona. La nuestra sirve para comparar supermercados: los mismos productos en todas las cadenas.']];
    return ['title' => 'Canasta de supermercado: cuánto cuesta en cada cadena', 'h1' => 'Canasta de supermercado: cuánto cuesta en cada cadena',
        'desc' => 'La misma canasta de ' . count($items) . ' productos en Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás y más. Hoy la más barata cuesta ' . ($t ? pesos(reset($t)) : '') . '.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'SEPA – Precios Claros'];
}
