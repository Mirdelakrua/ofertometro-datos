<?php
// Supermercados (cadenas) y ofertas.

function seccion_cadenas($D)
{
    if (!$D['ok']['precios']) return;
    registrar('/supermercados/', 0, 'precios', function () use ($D) { return cadenas_indice($D); });
    registrar('/ofertas/', 0, 'precios', function () use ($D) { return ofertas_indice($D); });
    foreach ($D['cadenas'] as $c => $info) {
        if (($info['productos'] ?? 0) < 60) continue;
        registrar(path_cadena($c), 0, 'precios', function () use ($D, $c) { return ficha_cadena($D, $c); });
        if (count(ofertas_de_cadena($D, $c)) >= 5) registrar(path_ofertas_cadena($c), 0, 'precios', function () use ($D, $c) { return ofertas_cadena($D, $c); });
    }
}

function ofertas_de_cadena($D, $c)
{
    static $cache = [];
    if (isset($cache[$c])) return $cache[$c];
    $o = [];
    foreach ($D['productos'] as $p) {
        if (empty($p['cad'][$c]['promo']) || !promo_vigente($p['cad'][$c]['promo'])) continue;
        $x = $p['cad'][$c];
        $o[] = [$p, [$c, $x['promo']['p'], promo_texto($x['promo']['txt'], $x['promo']['hasta'] ?? ''), $x['p'], $x['promo']['n']]];
    }
    usort($o, function ($a, $b) { return ($a[1][1] / $a[1][3]) <=> ($b[1][1] / $b[1][3]); });
    return $cache[$c] = $o;
}

function todas_las_ofertas($D)
{
    $o = [];
    foreach ($D['cadenas'] as $c => $_) foreach (ofertas_de_cadena($D, $c) as $x) $o[] = $x;
    usort($o, function ($a, $b) { return ($a[1][1] / $a[1][3]) <=> ($b[1][1] / $b[1][3]); });
    return $o;
}

function cadenas_indice($D)
{
    $f = [];
    $cads = $D['cadenas'];
    uasort($cads, function ($a, $b) { return $b['sucursales'] <=> $a['sucursales']; });
    foreach ($cads as $c => $x) {
        if (($x['productos'] ?? 0) < 60) continue;
        $provs = array_slice(array_keys($x['prov']), 0, 4);
        $f[] = [cadena_celda($D, $c, publicada(path_cadena($c))), num($x['sucursales']), e(implode(', ', array_map(function ($pv) use ($D) { return prov_nombre($D, $pv); }, $provs)) . (count($x['prov']) > 4 ? '…' : '')),
            isset($D['ranking'][$c]) ? e(frase_indice($x['indice'] / 100)) : '<span class="tenue">sin ranking</span>'];
    }
    $c = '<p class="intro">Las cadenas de supermercados que informan sus precios a diario al programa oficial Precios Claros: cuántas sucursales tienen, en qué provincias están y qué tan caras son comparadas con el resto.</p>'
        . tabla(['Supermercado', 'Sucursales', 'Provincias principales', 'Precios'], $f, [1])
        . '<p class="nota">"Precios" compara los mismos productos en todas las cadenas: 100% es el precio típico del mercado. Las cadenas con pocas sucursales o pocos productos relevados no entran en el ranking.</p>'
        . enlaces_relacionados([['/supermercado-mas-barato/', 'Supermercado más barato hoy'], ['/ofertas/', 'Ofertas de supermercados'], ['/canasta-basica-supermercado/', 'Canasta de supermercado']]);
    return ['title' => 'Supermercados de Argentina: sucursales y precios', 'h1' => 'Supermercados de Argentina',
        'desc' => 'Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás, La Anónima, Cooperativa Obrera y más: sucursales, provincias y qué tan caro es cada supermercado.',
        'cuerpo' => $c, 'fuente' => 'SEPA – Precios Claros'];
}

function ficha_cadena($D, $c)
{
    $x = $D['cadenas'][$c];
    $nom = $x['nombre'];
    $pos = array_search($c, array_keys($D['ranking']), true);
    $gana = []; $pierde = [];
    foreach ($D['productos'] as $p) {
        if (!isset($p['cad'][$c]) || count($p['cad']) < 6) continue;
        $mb = mas_barata($p);
        if ($mb[0] === $c) $gana[] = $p;
        if ($p['cad'][$c]['p'] >= $p['max'] && $p['max'] > $p['min'] * 1.05) $pierde[] = $p;
    }
    usort($gana, function ($a, $b) { return brecha($b) <=> brecha($a); });
    usort($pierde, function ($a, $b) { return brecha($b) <=> brecha($a); });
    $provs = $x['prov'];
    $c_html = '<div class="cad-cab">' . marca_cadena($D, $c, 56) . '<p class="intro">' . e($nom) . ' tiene <strong>' . num($x['sucursales']) . ' sucursales</strong> que informan precios a Precios Claros, en '
        . count($provs) . ' provincia' . (count($provs) == 1 ? '' : 's') . '. Relevamos ' . num($x['productos'] ?? 0) . ' de nuestros productos en sus góndolas.</p></div>';
    $claves = [['Sucursales', num($x['sucursales']), ''], ['Productos comparados', num($x['productos'] ?? 0), '']];
    if ($pos !== false) $claves[] = ['Ranking de precios', ($pos + 1) . '° de ' . count($D['ranking']), e(frase_indice($x['indice'] / 100))];
    $claves[] = ['Es la más barata en', num(count($gana)), 'productos'];
    $c_html .= datos_clave($claves);

    // Por categoría
    $f = [];
    foreach ($D['por_cat'] as $cat => $subs) {
        $prods = [];
        foreach ($subs as $s => $_) $prods = array_merge($prods, productos_de_sub($D, $s));
        $ind = indice_cadenas($D, $prods);
        if (!isset($ind[$c])) continue;
        $f[] = [enlace(path_cat($cat), cat_nombre($cat)), e(frase_indice($ind[$c])), (array_search($c, array_keys($ind), true) + 1) . '° de ' . count($ind)];
    }
    if ($f) $c_html .= '<h2>¿Es caro ' . e($nom) . '? Precios por categoría</h2>' . tabla(['Categoría', 'Comparado con el promedio', 'Posición'], $f, [2]);
    if ($gana) $c_html .= '<h2>Lo que conviene comprar en ' . e($nom) . '</h2><p>Productos en los que ' . e($nom) . ' tiene hoy el precio más bajo de todas las cadenas:</p>' . tabla_cadena($D, $c, array_slice($gana, 0, 15));
    if ($pierde) $c_html .= '<h2>Lo que conviene comprar en otro lado</h2><p>Productos donde ' . e($nom) . ' es la más cara:</p>' . tabla_cadena($D, $c, array_slice($pierde, 0, 10));
    $of = ofertas_de_cadena($D, $c);
    if ($of) $c_html .= '<h2>Ofertas de ' . e($nom) . '</h2>' . lista_ofertas($D, array_slice($of, 0, 6), false) . '<p>' . enlace(path_ofertas_cadena($c), 'Ver todas las ofertas de ' . $nom . ' (' . count($of) . ')') . '</p>';
    $fp = [];
    foreach ($provs as $pv => $n) $fp[] = [enlace(path_prov($D, $pv), prov_nombre($D, $pv)), num($n)];
    $c_html .= '<h2>Sucursales de ' . e($nom) . ' por provincia</h2>' . tabla(['Provincia', 'Sucursales'], $fp, [1]);
    $c_html .= enlaces_relacionados([['/supermercado-mas-barato/', 'Supermercado más barato hoy'], ['/supermercados/', 'Todos los supermercados'], ['/canasta-basica-supermercado/', 'Canasta en ' . $nom . ' y otras cadenas']]);
    $faqs = [['¿' . $nom . ' es barato?', $pos !== false ? 'Comparando los mismos productos, ' . e($nom) . ' está ' . e(frase_indice($x['indice'] / 100)) . ' y queda ' . ($pos + 1) . '° de ' . count($D['ranking']) . ' en nuestro ranking de supermercados.' : 'No tenemos suficientes productos relevados para ubicarlo en el ranking.'],
        ['¿Cuántas sucursales tiene ' . $nom . '?', e($nom) . ' informa precios de ' . num($x['sucursales']) . ' sucursales al programa Precios Claros.']];
    return ['title' => titulo_corto($nom . ': precios, ofertas y sucursales', $nom . ': precios y ofertas'), 'h1' => $nom . ': precios, ofertas y sucursales',
        'desc' => '¿Es caro ' . $nom . '? Comparamos sus precios con otros supermercados, qué productos conviene comprar ahí, sus ofertas y sucursales por provincia.',
        'migas' => [['Supermercados', '/supermercados/']], 'cuerpo' => $c_html, 'faqs' => $faqs, 'fuente' => 'SEPA – Precios Claros'];
}

function tabla_cadena($D, $c, $prods)
{
    $f = [];
    foreach ($prods as $p) {
        $mb = mas_barata($p);
        $f[] = [enlace(path_producto($p), $p['nombre']), '<strong>' . pesos($p['cad'][$c]['p']) . '</strong>', pesos($p['med']), $mb[0] === $c ? '<span class="tenue">—</span>' : e(cadena_nombre($D, $mb[0])) . ' ' . pesos($mb[1])];
    }
    return tabla(['Producto', 'Precio acá', 'Típico', 'Más barato en'], $f, [1, 2]);
}

function ofertas_indice($D)
{
    $todas = todas_las_ofertas($D);
    $c = '<p class="intro">Las <strong>' . num(count($todas)) . ' ofertas</strong> vigentes que las cadenas informan a Precios Claros, ordenadas por descuento. Se actualizan todos los días.</p>';
    $f = [];
    foreach ($D['cadenas'] as $cad => $_) {
        $n = count(ofertas_de_cadena($D, $cad));
        if ($n) $f[$cad] = $n;
    }
    arsort($f);
    $c .= '<div class="chips">';
    foreach ($f as $cad => $n) $c .= publicada(path_ofertas_cadena($cad)) ? '<a class="chip" href="' . e(path_ofertas_cadena($cad)) . '">' . e(cadena_nombre($D, $cad)) . ' <b>' . $n . '</b></a>' : '';
    $c .= '</div><h2>Mayores descuentos de hoy</h2>' . lista_ofertas($D, array_slice($todas, 0, 40));
    $c .= '<p class="nota">Las promociones pueden requerir llevar varias unidades, una tarjeta de la cadena o un medio de pago determinado. Mostramos el precio promocional por unidad que informa cada cadena.</p>';
    return ['title' => 'Ofertas de supermercados hoy: los mayores descuentos', 'h1' => 'Ofertas de supermercados de hoy',
        'desc' => 'Las mejores ofertas de Coto, Carrefour, Día, Jumbo, Disco, Vea y más, ordenadas por descuento. Promociones vigentes actualizadas a diario.',
        'cuerpo' => $c, 'fuente' => 'SEPA – Precios Claros'];
}

function ofertas_cadena($D, $c)
{
    $nom = cadena_nombre($D, $c);
    $of = ofertas_de_cadena($D, $c);
    $c_html = '<p class="intro">' . num(count($of)) . ' ofertas vigentes en <strong>' . enlace(path_cadena($c), $nom) . '</strong>, ordenadas por descuento.</p>' . lista_ofertas($D, array_slice($of, 0, 80), false)
        . '<p class="nota">El precio promocional puede requerir llevar más de una unidad o un medio de pago. Puede no estar disponible en todas las sucursales.</p>';
    $otras = [];
    foreach ($D['cadenas'] as $cad => $_) if ($cad !== $c) $otras[] = [path_ofertas_cadena($cad), 'Ofertas de ' . cadena_nombre($D, $cad)];
    $c_html .= enlaces_relacionados(array_merge([['/ofertas/', 'Todas las ofertas de supermercados']], array_slice($otras, 0, 8)));
    return ['title' => 'Ofertas de ' . $nom . ' hoy', 'h1' => 'Ofertas de ' . $nom . ' de hoy',
        'desc' => 'Las ofertas de ' . $nom . ' de esta semana: ' . count($of) . ' productos con descuento ordenados de mayor a menor. Actualizado a diario.',
        'migas' => [['Ofertas', '/ofertas/']], 'cuerpo' => $c_html, 'fuente' => 'SEPA – Precios Claros'];
}
