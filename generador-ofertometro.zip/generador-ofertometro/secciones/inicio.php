<?php
// Portada, buscador, páginas institucionales y mapa del sitio.

function seccion_inicio($D)
{
    registrar('/', 0, 'inicio', function () use ($D) { return inicio($D); });
    registrar('/buscar/', 0, 'inicio', function () use ($D) { return buscar($D); });
    registrar('/mapa-del-sitio/', 0, 'inicio', function () { return mapa_del_sitio(); });
    foreach (['acerca', 'fuentes', 'privacidad', 'terminos', 'contacto'] as $k) {
        registrar('/' . $k . '/', 0, 'inicio', function () use ($D, $k) { return call_user_func('legal_' . $k, $D); });
    }
}

function caja_busqueda($grande = false)
{
    return '<form class="busca' . ($grande ? ' busca-grande' : '') . '" action="/buscar/" method="get" role="search">'
        . '<label for="q" class="oculto">Buscar un producto</label>'
        . '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.5-4.5"/></svg>'
        . '<input id="q" name="q" type="search" autocomplete="off" placeholder="Buscá un producto: yerba, aceite, leche…" data-buscador>'
        . '<button type="submit">Comparar</button><ul class="sugerencias" hidden></ul></form>';
}

function inicio($D)
{
    $fecha = fecha_datos($D);
    $hero = '<div class="hero-int"><div class="hero-txt"><p class="hero-dato"><span class="punto"></span>Precios del ' . e(fecha_larga($fecha)) . '</p>'
        . '<h1>Compará precios de supermercado y encontrá el más barato</h1>'
        . '<p class="hero-lead">' . num(count($D['productos'] ?? [])) . ' productos en ' . num(count($D['ranking'] ?? [])) . ' cadenas y ' . num($D['meta']['sucursales'] ?? 0) . ' sucursales de todo el país, con los datos oficiales que cada supermercado informa a diario.</p>'
        . caja_busqueda(true) . '</div>';
    if (!$D['ok']['precios']) {
        return ['title' => 'Ofertómetro: comparador de precios de supermercados', 'h1' => 'Comparador de precios de supermercados', 'desc' => cfg('sitio_lema'),
            'hero' => $hero . '</div>', 'cuerpo' => aviso('Estamos cargando los precios de hoy. Volvé en unos minutos.'), 'sin_aviso_legal' => true];
    }
    $t = totales_canasta($D);
    if ($t) {
        $ct = array_key_first($t);
        $hero .= '<a class="hero-ticket" href="/canasta-basica-supermercado/" aria-label="Ver la canasta de supermercado">' . ticket_canasta($D, $ct, $t[$ct], 5) . '<span class="hero-ticket-pie">La canasta más barata de hoy →</span></a>';
    }
    $hero .= '</div>';

    $g = array_key_first($D['ranking']);
    $ind = [];
    foreach ($D['ranking'] as $cad => $v) $ind[$cad] = $v / 100;
    $c = '<section class="bloque"><div class="bloque-cab"><h2>Supermercado más barato hoy</h2>' . enlace('/supermercado-mas-barato/', 'Ver ranking y por provincia', 'ver-mas') . '</div>'
        . '<p>Comparando los mismos productos en todas las cadenas, hoy gana <strong>' . e(cadena_nombre($D, $g)) . '</strong>.</p>' . barras_indice($D, $ind, 8, true) . '</section>';

    // Categorías
    $c .= '<section class="bloque"><h2>Precios por categoría</h2><div class="cats">';
    foreach ($D['por_cat'] as $cat => $subs) {
        $c .= '<section class="cat"><h3>' . icono_cat($cat) . ' ' . enlace(path_cat($cat), cat_nombre($cat)) . '</h3><ul>';
        foreach (array_slice(array_keys($subs), 0, 7) as $s) $c .= '<li>' . enlace(path_sub($D, $s), sub_nombre($D, $s)) . '</li>';
        $c .= '</ul></section>';
    }
    $c .= '</div></section>';

    // Mayor diferencia de precios
    // Sólo cadenas del ranking (grandes y con muchos productos), así el "duelo" es entre supermercados comparables
    $prods = [];
    foreach ($D['productos'] as $p) {
        if (!publicada(path_producto($p))) continue;
        $p['cad'] = array_intersect_key($p['cad'], $D['ranking']);
        if (count($p['cad']) < 6) continue;
        $ps = array_column($p['cad'], 'p');
        $p['min'] = min($ps); $p['max'] = max($ps);
        $prods[] = $p;
    }
    usort($prods, function ($a, $b) { return brecha($b) <=> brecha($a); });
    $c .= '<section class="bloque"><h2>Lo mismo, mucho más barato</h2><p>Productos idénticos con la mayor diferencia de precio entre supermercados hoy:</p><div class="duelos">';
    foreach (array_slice($prods, 0, 6) as $p) {
        $mb = mas_barata($p);
        $caro = mas_cara($p);
        $c .= '<a class="duelo" href="' . e(path_producto($p)) . '"><strong>' . e($p['nombre']) . '</strong><span class="du-fila du-bien"><i>' . e(cadena_nombre($D, $mb[0])) . '</i>' . pesos($mb[1]) . '</span>'
            . '<span class="du-fila du-mal"><i>' . e(cadena_nombre($D, $caro[0])) . '</i>' . pesos($caro[1]) . '</span><span class="du-dif">' . pct_txt(brecha($p)) . ' de diferencia</span></a>';
    }
    $c .= '</div></section>';

    // Ofertas
    $of = todas_las_ofertas($D);
    if ($of) $c .= '<section class="bloque"><div class="bloque-cab"><h2>Ofertas destacadas</h2>' . enlace('/ofertas/', 'Ver todas las ofertas', 'ver-mas') . '</div>' . lista_ofertas($D, array_slice($of, 0, 8)) . '</section>';

    // Provincias
    $provs = $D['canasta']['provincias'] ?? [];
    uksort($provs, function ($a, $b) use ($D) { return strcmp(prov_nombre($D, $a), prov_nombre($D, $b)); });
    $c .= '<section class="bloque"><h2>Supermercado más barato en tu provincia</h2><ul class="provs">';
    foreach ($provs as $pv => $fila) {
        if (count($fila) < 2) continue;
        $c .= '<li><a href="' . e(path_prov($D, $pv)) . '"><span>' . e(prov_nombre($D, $pv)) . '</span><small>' . e(cadena_nombre($D, array_key_first($fila))) . '</small></a></li>';
    }
    $c .= '</ul></section>';
    $c .= '<section class="bloque como"><h2>Cómo funciona</h2><ol class="pasos"><li><strong>Datos oficiales.</strong> Las cadenas grandes están obligadas a informar todos los días el precio de cada producto en cada sucursal al SEPA, la base de Precios Claros.</li>'
        . '<li><strong>Los mismos productos.</strong> Comparamos por código de barras (EAN): mismo producto, misma marca, misma presentación.</li>'
        . '<li><strong>Todos los días.</strong> Procesamos más de 15 millones de precios por día y actualizamos rankings, canasta y ofertas.</li></ol></section>';
    $faqs = [['¿Cuál es el supermercado más barato?', 'Hoy, comparando los mismos productos, ' . e(cadena_nombre($D, $g)) . ' (' . e(frase_indice($ind[$g])) . '). ' . enlace('/supermercado-mas-barato/', 'Ver el ranking completo') . '.'],
        ['¿Los precios son de todas las sucursales?', 'Usamos el precio más común entre las sucursales de cada cadena. En la ficha de cada producto también mostramos el rango entre la sucursal más barata y la más cara.']];
    return ['title' => 'Ofertómetro: comparador de precios de supermercados', 'h1' => 'Compará precios de supermercado y encontrá el más barato',
        'desc' => 'Compará precios de ' . num(count($D['productos'])) . ' productos en Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás y más. Supermercado más barato hoy, canasta y ofertas.',
        'hero' => $hero, 'cuerpo' => barra_provincia(true, true) . $c, 'faqs' => $faqs, 'js' => true];
}

function buscar($D)
{
    $c = caja_busqueda(true) . '<div id="resultados" class="resultados" aria-live="polite"></div>'
        . '<noscript><p>El buscador necesita JavaScript. También podés navegar ' . enlace('/precios/', 'los precios por categoría') . '.</p></noscript>'
        . '<h2>Categorías</h2><ul class="chips">';
    foreach ($D['meta']['subcategorias'] ?? [] as $s => $n) $c .= publicada(path_sub($D, $s)) ? '<li><a class="chip" href="' . e(path_sub($D, $s)) . '">' . e($n) . '</a></li>' : '';
    $c .= '</ul>';
    return ['title' => 'Buscar precios de productos de supermercado', 'h1' => 'Buscar un producto', 'desc' => 'Buscá cualquier producto y compará su precio en todos los supermercados.',
        'cuerpo' => $c, 'js' => true, 'noindex' => true, 'sin_aviso_legal' => true];
}

function mapa_del_sitio()
{
    $grupos = [];
    foreach ($GLOBALS['TITULOS'] as $path => $tit) {
        if (strpos($path, '/precio/') === 0) $g = 'Productos';
        elseif (strpos($path, '/precios/') === 0) $g = 'Precios por categoría';
        elseif (strpos($path, '/supermercado-mas-barato/') === 0) $g = 'Supermercado más barato';
        elseif (strpos($path, '/supermercados/') === 0 || strpos($path, '/ofertas/') === 0) $g = 'Supermercados y ofertas';
        elseif (in_array($path, ['/acerca/', '/fuentes/', '/privacidad/', '/terminos/', '/contacto/', '/', '/buscar/'], true)) $g = cfg('sitio_nombre');
        else $g = 'Supermercado más barato';
        $grupos[$g][$path] = $tit;
    }
    $c = '<p class="intro">Todas las páginas de ' . e(cfg('sitio_nombre')) . '. También está el <a href="/sitemap.xml">sitemap XML</a> para buscadores.</p>';
    foreach (['Supermercado más barato', 'Precios por categoría', 'Supermercados y ofertas', 'Productos', cfg('sitio_nombre')] as $g) {
        if (empty($grupos[$g])) continue;
        asort($grupos[$g]);
        $c .= '<h2>' . e($g) . '</h2><ul class="mapa">';
        foreach ($grupos[$g] as $path => $tit) $c .= '<li><a href="' . e($path) . '">' . e($tit) . '</a></li>';
        $c .= '</ul>';
    }
    return ['title' => 'Mapa del sitio', 'h1' => 'Mapa del sitio', 'desc' => 'Todas las páginas de Ofertómetro: precios por producto y categoría, supermercado más barato por provincia, canasta y ofertas.', 'cuerpo' => $c, 'sin_aviso_legal' => true];
}

function legal_acerca($D)
{
    $c = '<p class="intro">Ofertómetro es un comparador argentino e <strong>independiente</strong> de precios de supermercado. Nació de una pregunta simple: ¿dónde conviene hacer las compras?</p>'
        . '<p>Todos los días procesamos los precios que las grandes cadenas están obligadas a informar al Estado y los ordenamos para que se puedan comparar: producto por producto, por categoría, por provincia y con una canasta fija.</p>'
        . '<h2>Qué no somos</h2><p>No vendemos productos, no somos una cadena de supermercados ni un organismo oficial, y ninguna cadena paga por aparecer o por su posición en los rankings.</p>'
        . '<p>El sitio se financia con publicidad. Si ves un error, escribinos desde ' . enlace('/contacto/', 'contacto') . '.</p>';
    return ['title' => 'Quiénes somos', 'h1' => 'Quiénes somos', 'desc' => 'Ofertómetro es un comparador independiente de precios de supermercados de Argentina con datos oficiales diarios.', 'cuerpo' => $c];
}

function legal_fuentes($D)
{
    $c = '<p class="intro">Todos los precios de Ofertómetro salen del <strong>SEPA (Sistema Electrónico de Publicidad de Precios Argentinos)</strong>, creado por la Resolución 12/2016 de la Secretaría de Comercio. '
        . 'Las cadenas de supermercados alcanzadas deben informar a diario el precio de cada producto en cada sucursal. Es la misma base que usa Precios Claros.</p>'
        . '<p>El dataset se publica en <a href="https://datos.produccion.gob.ar/dataset/sepa-precios" rel="nofollow noopener" target="_blank">datos.produccion.gob.ar</a> bajo licencia Creative Commons Atribución 4.0.</p>'
        . '<h2>Cómo procesamos los datos</h2><ul><li>Identificamos cada producto por su código de barras (EAN), así comparamos exactamente lo mismo.</li>'
        . '<li>Para cada cadena tomamos el precio de lista más común entre sus sucursales (la mediana) y descartamos valores absurdos (errores de carga).</li>'
        . '<li>El ranking de supermercados compara, producto por producto, el precio de cada cadena con el precio típico del mercado y resume con la mediana.</li>'
        . '<li>Las promociones son las que informa cada cadena; pueden tener condiciones (cantidad mínima, medio de pago, tarjeta de la cadena).</li></ul>'
        . '<p>Última actualización de los datos: <strong>' . e(fecha_larga(fecha_datos($D))) . '</strong>.</p>';
    return ['title' => 'Fuentes de los datos', 'h1' => 'Fuentes de los datos', 'desc' => 'De dónde salen los precios de Ofertómetro: el SEPA (Precios Claros) de la Secretaría de Comercio, y cómo los procesamos.', 'cuerpo' => $c];
}

function legal_privacidad($D)
{
    $c = '<p>En Ofertómetro no pedimos registro ni guardamos datos personales. El buscador funciona en tu navegador.</p>'
        . '<h2>Cookies y publicidad</h2><p>Este sitio puede mostrar anuncios de Google AdSense. Google y otros proveedores usan cookies para mostrar anuncios basados en tus visitas anteriores a este y otros sitios. '
        . 'Podés desactivar la publicidad personalizada en la <a href="https://adssettings.google.com" rel="nofollow noopener" target="_blank">configuración de anuncios de Google</a>.</p>'
        . '<h2>Estadísticas</h2><p>Podemos usar Google Analytics para conocer de forma agregada qué páginas se visitan.</p>'
        . '<h2>Tus derechos</h2><p>De acuerdo con la Ley 25.326, podés escribirnos a ' . e(cfg('email_contacto')) . '.</p>';
    return ['title' => 'Política de privacidad', 'h1' => 'Política de privacidad', 'desc' => 'Política de privacidad de Ofertómetro: no guardamos datos personales; cómo usamos las cookies de publicidad.', 'cuerpo' => $c];
}

function legal_terminos($D)
{
    $c = '<p>Ofertómetro publica precios de supermercados con fines exclusivamente informativos.</p>'
        . '<h2>Exactitud de los precios</h2><p>Los precios son los que informan las cadenas al SEPA y pueden variar por sucursal, día, stock o medio de pago. Hacemos lo posible para mostrarlos bien, pero pueden contener demoras o errores. El precio que vale es el de la góndola.</p>'
        . '<h2>Marcas</h2><p>Los nombres de cadenas y productos pertenecen a sus dueños y se usan sólo para identificar lo que se compara. Ofertómetro no tiene relación comercial con ellas.</p>';
    return ['title' => 'Términos de uso', 'h1' => 'Términos de uso', 'desc' => 'Términos de uso de Ofertómetro: precios informativos de supermercados según el SEPA.', 'cuerpo' => $c];
}

function legal_contacto($D)
{
    $m = e(cfg('email_contacto'));
    $c = '<p class="intro">¿Viste un precio que no coincide con la góndola, un producto mal clasificado o querés sugerir algo? Escribinos a <strong>' . $m . '</strong>.</p>'
        . '<p>Si es un precio, contanos el producto, la cadena y la sucursal.</p>';
    return ['title' => 'Contacto', 'h1' => 'Contacto', 'desc' => 'Contactá a Ofertómetro para reportar un precio o sugerir mejoras.', 'cuerpo' => $c];
}
