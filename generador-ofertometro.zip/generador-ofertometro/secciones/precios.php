<?php
// Precios: índice de categorías, categoría, subcategoría y ficha de cada producto.

function seccion_precios($D)
{
    if (!$D['ok']['precios']) return;
    registrar('/precios/', 0, 'precios', function () use ($D) { return precios_indice($D); });
    foreach ($D['por_cat'] as $c => $subs) {
        registrar(path_cat($c), 0, 'precios', function () use ($D, $c) { return precios_cat($D, $c); });
        foreach ($subs as $s => $_) registrar(path_sub($D, $s), 0, 'precios', function () use ($D, $s) { return precios_sub($D, $s); });
    }
    // Las fichas más buscadas (más sucursales relevadas) salen el primer día; el resto, de a poco
    $orden = $D['productos'];
    usort($orden, function ($a, $b) { return total_suc($b) <=> total_suc($a); });
    foreach ($orden as $k => $p) {
        registrar(path_producto($p), $k < 320 ? 0 : 1 + intdiv($k, 60), 'precios', function () use ($D, $p) { return ficha_producto($D, $p); });
    }
}

function total_suc($p)
{
    $n = 0;
    foreach ($p['cad'] as $x) $n += $x['n'];
    return $n;
}

function pct_txt($f, $dec = 0)
{
    return num($f * 100, $dec) . '%';
}

// ---------- Índice ----------

function precios_indice($D)
{
    $c = '<p class="intro">Precios de <strong>' . num(count($D['productos'])) . ' productos</strong> de supermercado en las principales cadenas del país, '
        . 'actualizados con lo que cada cadena informa a diario al programa oficial Precios Claros. Elegí una categoría:</p><div class="cats">';
    foreach ($D['por_cat'] as $cat => $subs) {
        $c .= '<section class="cat"><h2>' . icono_cat($cat) . ' ' . enlace(path_cat($cat), cat_nombre($cat)) . '</h2><ul>';
        foreach ($subs as $s => $_) $c .= '<li>' . enlace(path_sub($D, $s), sub_nombre($D, $s)) . ' <span class="tenue">' . count($D['por_sub'][$s]) . '</span></li>';
        $c .= '</ul></section>';
    }
    $c .= '</div>';
    return ['title' => 'Precios de supermercado hoy por categoría', 'h1' => 'Precios de supermercado por categoría',
        'desc' => 'Compará precios de almacén, lácteos, bebidas, limpieza y perfumería en Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás y más cadenas. Datos oficiales diarios.',
        'cuerpo' => $c, 'fuente' => 'SEPA – Precios Claros'];
}

// Índice de una cadena dentro de un conjunto de productos (100 = precio típico)
function indice_cadenas($D, $prods, $min = 8)
{
    $rel = [];
    foreach ($prods as $p) foreach ($p['cad'] as $c => $x) if (isset($D['ranking'][$c])) $rel[$c][] = $x['p'] / $p['med'];
    $out = [];
    foreach ($rel as $c => $v) {
        if (count($v) < $min) continue;
        sort($v);
        $m = count($v);
        $out[$c] = $m % 2 ? $v[intdiv($m, 2)] : ($v[$m / 2 - 1] + $v[$m / 2]) / 2;
    }
    asort($out);
    return $out;
}

function frase_indice($i)
{
    $d = round(($i - 1) * 100, 1);
    if (abs($d) < 0.5) return 'en el promedio';
    return num(abs($d), abs($d) < 10 ? 1 : 0) . '% ' . ($d < 0 ? 'más barato' : 'más caro') . ' que el promedio';
}

function barras_indice($D, $ind, $max = 12, $provincial = false)
{
    if (!$ind) return '';
    $vals = array_slice($ind, 0, $max, true);
    $lo = min($vals); $hi = max($vals);
    $span = max(0.02, $hi - $lo);
    $h = '<ol class="podio"' . ($provincial ? ' data-podio-prov="' . $max . '"' : '') . '>';
    $k = 0;
    foreach ($vals as $c => $v) {
        $k++;
        $w = 18 + 82 * (($v - $lo) / $span);
        $h .= '<li data-cad-flt="' . e($c) . '"' . ($k === 1 ? ' class="gana"' : '') . '><span class="po-n">' . $k . '</span><span class="po-cad">' . cadena_celda($D, $c) . '</span>'
            . '<span class="po-barra"><i style="width:' . round($w, 1) . '%"></i></span><span class="po-val">' . e(frase_indice($v)) . '</span></li>';
    }
    return $h . '</ol>';
}

// ---------- Categoría ----------

function precios_cat($D, $cat)
{
    $prods = [];
    foreach ($D['por_cat'][$cat] as $s => $_) $prods = array_merge($prods, productos_de_sub($D, $s));
    $ind = indice_cadenas($D, $prods);
    $nom = cat_nombre($cat);
    $c = '<p class="intro">Precios de <strong>' . count($prods) . ' productos de ' . e(mb_strtolower($nom, 'UTF-8')) . '</strong> (' . e(CATEGORIAS[$cat]['desc']) . ') comparados entre supermercados.</p>';
    if ($ind) {
        $g = array_key_first($ind);
        $c .= '<h2>¿Qué supermercado es más barato en ' . e(mb_strtolower($nom, 'UTF-8')) . '?</h2><p>Comparando los mismos productos, <strong>' . e(cadena_nombre($D, $g)) . '</strong> es la cadena más barata en esta categoría: '
            . e(frase_indice($ind[$g])) . '.</p>' . barras_indice($D, $ind);
    }
    $c .= '<h2>Subcategorías</h2><div class="subs">';
    foreach ($D['por_cat'][$cat] as $s => $_) {
        $ps = productos_de_sub($D, $s);
        $minp = min(array_column($ps, 'min'));
        $c .= '<a class="sub" href="' . e(path_sub($D, $s)) . '"><strong>' . e(sub_nombre($D, $s)) . '</strong><span>' . count($ps) . ' productos · desde ' . pesos($minp) . '</span></a>';
    }
    $c .= '</div>';
    usort($prods, function ($a, $b) { return brecha($b) <=> brecha($a); });
    $c .= '<h2>Donde más conviene comparar</h2><p>Los productos de ' . e(mb_strtolower($nom, 'UTF-8')) . ' con más diferencia de precio entre cadenas hoy:</p>' . tabla_productos($D, array_slice($prods, 0, 12));
    return ['title' => 'Precios de ' . mb_strtolower($nom, 'UTF-8') . ' en supermercados hoy', 'h1' => 'Precios de ' . mb_strtolower($nom, 'UTF-8') . ' en supermercados',
        'desc' => 'Compará hoy precios de ' . CATEGORIAS[$cat]['desc'] . ' en Coto, Carrefour, Día, Jumbo, Vea y más. Qué supermercado es más barato en ' . mb_strtolower($nom, 'UTF-8') . '.',
        'migas' => [['Precios', '/precios/']], 'cuerpo' => $c, 'fuente' => 'SEPA – Precios Claros', 'prov' => true];
}

function tabla_productos($D, $prods, $col_sub = false)
{
    $f = [];
    foreach ($prods as $p) {
        $mb = mas_barata($p);
        $f[] = [enlace(path_producto($p), $p['nombre']), cadena_celda($D, $mb[0], false), '<strong>' . pesos($mb[1]) . '</strong>', pesos($p['med']), pesos($p['max']),
            '<span class="dif">' . pct_txt(brecha($p)) . '</span>',
            '_attr' => "data-pv-prod='" . e(json_encode(pv_producto($p), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . "'"];
    }
    return tabla(['Producto', 'Más barato en', 'Precio', 'Típico', 'Más caro', 'Diferencia'], $f, [2, 3, 4, 5]);
}

// ---------- Subcategoría ----------

function precios_sub($D, $s)
{
    $prods = productos_de_sub($D, $s);
    $cat = $prods[0]['cat'];
    $nom = sub_nombre($D, $s);
    $nl = mb_strtolower($nom, 'UTF-8');
    $ind = indice_cadenas($D, $prods, 5);
    usort($prods, function ($a, $b) { return total_suc($b) <=> total_suc($a); });
    $baratos = $prods;
    usort($baratos, function ($a, $b) { return $a['min'] <=> $b['min']; });
    $c = '<p class="intro">Comparamos el precio de <strong>' . count($prods) . ' productos de ' . e($nl) . '</strong> en ' . count(array_unique(array_merge(...array_map(function ($p) { return array_keys($p['cad']); }, $prods)))) . ' cadenas de supermercados. '
        . 'El más económico hoy es <strong>' . enlace(path_producto($baratos[0]), $baratos[0]['nombre']) . '</strong>, desde ' . pesos($baratos[0]['min']) . ' en ' . e(cadena_nombre($D, mas_barata($baratos[0])[0])) . '.</p>';
    $c .= tabla_productos($D, $prods);
    if (count($ind) >= 3) {
        $g = array_key_first($ind);
        $c .= '<h2>¿Dónde conviene comprar ' . e($nl) . '?</h2><p>Comparando los mismos productos, <strong>' . e(cadena_nombre($D, $g)) . '</strong> tiene los precios más bajos en ' . e($nl) . ' (' . e(frase_indice($ind[$g])) . ').</p>' . barras_indice($D, $ind, 8);
    }
    $of = [];
    foreach ($prods as $p) foreach (ofertas_producto($p) as $o) $of[] = [$p, $o];
    if ($of) {
        usort($of, function ($a, $b) { return ($a[1][1] / $a[1][3]) <=> ($b[1][1] / $b[1][3]); });
        $c .= '<h2>Ofertas de ' . e($nl) . '</h2>' . lista_ofertas($D, array_slice($of, 0, 8));
    }
    $otras = [];
    foreach ($D['por_cat'][$cat] as $ss => $_) if ($ss !== $s) $otras[] = [path_sub($D, $ss), 'Precio de ' . mb_strtolower(sub_nombre($D, $ss), 'UTF-8')];
    $c .= enlaces_relacionados(array_merge([[path_cat($cat), 'Precios de ' . mb_strtolower(cat_nombre($cat), 'UTF-8')], ['/supermercado-mas-barato/', 'Supermercado más barato hoy']], array_slice($otras, 0, 8)));
    $faqs = [["¿Dónde está más barato el {$nl}?", 'Hoy el precio más bajo lo tiene ' . e(cadena_nombre($D, mas_barata($baratos[0])[0])) . ' con ' . e($baratos[0]['nombre']) . ' a ' . pesos($baratos[0]['min']) . '. ' . (isset($g) ? 'En promedio, la cadena más barata en ' . e($nl) . ' es ' . e(cadena_nombre($D, $g)) . '.' : '')],
        ["¿Cada cuánto se actualizan los precios de {$nl}?", 'Todos los días. Las cadenas informan sus precios al programa oficial Precios Claros (SEPA) y nosotros los procesamos a diario.']];
    return ['title' => titulo_corto("Precio de {$nl} hoy: dónde está más barato", "Precio de {$nl} hoy en supermercados"), 'h1' => "Precio de {$nl} hoy en supermercados",
        'desc' => "Precio de {$nl} hoy en Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás y más. Compará " . count($prods) . " productos y mirá dónde está más barato.",
        'migas' => [['Precios', '/precios/'], [cat_nombre($cat), path_cat($cat)]], 'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'SEPA – Precios Claros', 'prov' => true];
}

function lista_ofertas($D, $of, $con_cadena = true)
{
    $h = '<ul class="ofertas">';
    foreach ($of as $x) {
        [$p, $o] = $x;
        $desc = 1 - $o[1] / $o[3];
        $h .= '<li data-cad-flt="' . e($o[0]) . '"><span class="of-pct">−' . num($desc * 100) . '%</span><span class="of-nom">' . enlace(path_producto($p), $p['nombre'])
            . ($con_cadena ? '<small>' . e(cadena_nombre($D, $o[0])) . ' · ' . e($o[2]) . '</small>' : '<small>' . e($o[2]) . '</small>') . '</span>'
            . '<span class="of-pre"><s>' . pesos($o[3]) . '</s>' . precio_gondola($o[1]) . '</span></li>';
    }
    return $h . '</ul>';
}

// ---------- Ficha de producto ----------

function ficha_producto($D, $p)
{
    $nom = $p['nombre'];
    $mb = mas_barata($p);
    $cads = $p['cad'];
    uasort($cads, function ($a, $b) { return $a['p'] <=> $b['p']; });
    $caro = mas_cara($p)[0];
    $ahorro = $p['max'] - $p['min'];
    $fecha = fecha_datos($D);

    $cab = '<div class="ficha"><div class="ficha-txt"><p class="ficha-cat">' . enlace(path_sub($D, $p['sub']), sub_nombre($D, $p['sub'])) . ($p['marca'] ? ' · ' . e($p['marca']) : '') . '</p>'
        . '<h1>' . e($nom) . '</h1><p class="ficha-lead">Precio hoy en ' . count($cads) . ' supermercados. Más barato en <strong>' . e(cadena_nombre($D, $mb[0])) . '</strong>.</p></div>'
        . '<div class="etiqueta" role="img" aria-label="Precio más bajo: ' . e(pesos($mb[1])) . ' en ' . e(cadena_nombre($D, $mb[0])) . '" data-etiqueta><span class="et-top" data-et-top>Mejor precio</span>' . precio_gondola($mb[1], 'pg-grande')
        . '<span class="et-cad" data-et-cad>' . e(cadena_nombre($D, $mb[0])) . '</span><span class="et-ean">EAN ' . e($p['ean']) . '</span></div></div>';

    $c = !empty($p['viejo']) ? aviso('Hoy ninguna cadena informó el precio de este producto. Te mostramos los últimos precios que tenemos, del <strong>' . e(fecha_larga($p['viejo'], false)) . '</strong>.', 'alerta') : '';
    $c .= datos_clave([
        ['Precio más bajo', pesos($p['min']), e(cadena_nombre($D, $mb[0]))],
        ['Precio típico', pesos($p['med']), 'mediana entre cadenas'],
        ['Precio más alto', pesos($p['max']), e(cadena_nombre($D, $caro))],
        ['Te ahorrás', pesos($ahorro), pct_txt(brecha($p)) . ' de diferencia'],
    ]);

    // Tabla por cadena
    $f = [];
    foreach ($cads as $cad => $x) {
        $promo = !empty($x['promo']) && promo_vigente($x['promo']) ? '<span class="chip-promo" title="' . e($x['promo']['txt']) . '">' . pesos($x['promo']['p']) . '</span>' : '<span class="tenue">—</span>';
        $f[] = [cadena_celda($D, $cad), '<strong>' . pesos($x['p']) . '</strong>', $x['min'] == $x['max'] ? '<span class="tenue">igual en todas</span>' : pesos($x['min']) . ' – ' . pesos($x['max']), num($x['n']), $promo, '_attr' => 'data-cad="' . e($cad) . '"'];
    }
    $pvdat = [];
    foreach ($p['prov'] ?? [] as $pv => $fila) foreach ($fila as $x) $pvdat[$pv][$x[0]] = [$x[1], $x[2]];
    $c .= '<h2>Precio de ' . e($nom) . ' en cada supermercado<span class="h-prov" data-pv-titulo></span></h2>' . datos_js('ofe-ficha', $pvdat)
        . tabla(['Supermercado', 'Precio', 'Rango entre sucursales', 'Sucursales', 'Promo'], $f, [1, 2, 3, 4], 0, 'Precio de lista más común entre las sucursales de cada cadena, al ' . fecha_corta($fecha));
    $c .= '<p class="nota">El precio es el más común entre las sucursales de cada cadena. La promo es el precio promocional más bajo informado (puede requerir llevar más de una unidad o un medio de pago).</p>';

    $of = ofertas_producto($p);
    if ($of) {
        $c .= '<h2>Ofertas de ' . e($nom) . '</h2><ul class="ofertas">';
        foreach ($of as $o) {
            $c .= '<li data-cad-flt="' . e($o[0]) . '"><span class="of-pct">−' . num((1 - $o[1] / $o[3]) * 100) . '%</span><span class="of-nom">' . enlace(path_ofertas_cadena($o[0]), 'Ofertas de ' . cadena_nombre($D, $o[0]))
                . '<small>' . e($o[2]) . ' · en ' . num($o[4]) . ' sucursal' . ($o[4] == 1 ? '' : 'es') . '</small></span><span class="of-pre"><s>' . pesos($o[3]) . '</s>' . precio_gondola($o[1]) . '</span></li>';
        }
        $c .= '</ul>';
    }

    // Por provincia
    if (!empty($p['prov'])) {
        $f = [];
        $prov = $p['prov'];
        uksort($prov, function ($a, $b) use ($D) { return strcmp(prov_nombre($D, $a), prov_nombre($D, $b)); });
        foreach ($prov as $pv => $fila) {
            if (!$fila) continue;
            $f[] = [enlace(path_prov($D, $pv), prov_nombre($D, $pv)), cadena_celda($D, $fila[0][0], false), '<strong>' . pesos($fila[0][1]) . '</strong>', count($fila) > 1 ? e(cadena_nombre($D, $fila[1][0])) . ' ' . pesos($fila[1][1]) : '—'];
        }
        $c .= '<h2>¿Dónde está más barato en tu provincia?</h2>' . tabla(['Provincia', 'Más barato en', 'Precio', 'Segunda opción'], $f, [2]);
    }

    // Evolución
    $hist = historial_producto($D, $p);
    if (count($hist) >= 7) {
        $c .= '<h2>Evolución del precio</h2>' . grafico('p-' . $p['slug'], svg_linea($hist, 'Precio típico de ' . $nom, 'Mediana del precio entre supermercados, día por día', 'pesos'),
            'Gráfico de la evolución del precio de ' . $nom . ' en supermercados', 'Evolución del precio de ' . $nom);
    }

    // Relacionados
    $sim = array_values(array_filter(productos_de_sub($D, $p['sub']), function ($x) use ($p) { return $x['ean'] !== $p['ean']; }));
    usort($sim, function ($a, $b) use ($p) {
        $ma = $a['marca'] === $p['marca'] ? 0 : 1; $mb = $b['marca'] === $p['marca'] ? 0 : 1;
        return $ma <=> $mb ?: total_suc($b) <=> total_suc($a);
    });
    $sim = array_filter(array_slice($sim, 0, 14), function ($x) { return publicada(path_producto($x)); });
    if ($sim) {
        $c .= '<h2>Otros productos de ' . e(mb_strtolower(sub_nombre($D, $p['sub']), 'UTF-8')) . '</h2><ul class="similares">';
        foreach (array_slice($sim, 0, 10) as $x) {
            $c .= '<li><a href="' . e(path_producto($x)) . '">' . e($x['nombre']) . '</a><span>desde ' . pesos($x['min']) . '</span></li>';
        }
        $c .= '</ul>';
    }
    $c .= enlaces_relacionados([[path_sub($D, $p['sub']), 'Precio de ' . mb_strtolower(sub_nombre($D, $p['sub']), 'UTF-8') . ' en supermercados'],
        [path_cadena($mb[0]), 'Supermercado ' . cadena_nombre($D, $mb[0])], ['/supermercado-mas-barato/', 'Supermercado más barato hoy'], ['/canasta-basica-supermercado/', 'Canasta de supermercado por cadena']]);

    $faqs = [
        ['¿Dónde está más barato ' . $nom . '?', 'Hoy el precio más bajo está en ' . e(cadena_nombre($D, $mb[0])) . ': ' . pesos($mb[1]) . '. El más alto es en ' . e(cadena_nombre($D, $caro)) . ' (' . pesos($p['max']) . ').'],
        ['¿Cuánto cuesta ' . $nom . '?', 'El precio típico entre supermercados es ' . pesos($p['med']) . ', con un rango de ' . pesos($p['min']) . ' a ' . pesos($p['max']) . ' según la cadena (datos del ' . e(fecha_larga($fecha, false)) . ').'],
    ];
    $offers = ['@type' => 'AggregateOffer', 'priceCurrency' => 'ARS', 'lowPrice' => $p['min'], 'highPrice' => $p['max'], 'offerCount' => count($cads), 'availability' => 'https://schema.org/InStock'];
    $prod = ['@type' => 'Product', 'name' => $nom, 'gtin13' => strlen($p['ean']) === 13 ? $p['ean'] : null, 'sku' => $p['ean'], 'category' => sub_nombre($D, $p['sub']), 'offers' => $offers,
        'image' => url_abs('/img/producto/' . $p['slug'] . '.svg')];
    if ($p['marca']) $prod['brand'] = ['@type' => 'Brand', 'name' => $p['marca']];
    $prod = array_filter($prod, function ($v) { return $v !== null; });
    imagen_producto($D, $p);

    $nl = $nom;
    return ['title' => titulo_corto('Precio de ' . $nl . ' hoy: dónde está más barato', 'Precio de ' . $nl . ' hoy'),
        'h1' => $nom, 'encabezado' => $cab,
        'desc' => $nom . ': hoy desde ' . pesos($p['min']) . ' en ' . cadena_nombre($D, $mb[0]) . '. Compará el precio en ' . count($cads) . ' supermercados y ahorrá hasta ' . pesos($ahorro) . '.',
        'migas' => [['Precios', '/precios/'], [cat_nombre($p['cat']), path_cat($p['cat'])], [sub_nombre($D, $p['sub']), path_sub($D, $p['sub'])]],
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'SEPA – Precios Claros', 'schema_extra' => [$prod], 'prov' => true];
}

// Imagen de la ficha: una "etiqueta de góndola" con el nombre y el precio (sirve para Google Imágenes y redes)
function imagen_producto($D, $p)
{
    $mb = mas_barata($p);
    $lineas = wordwrap($p['nombre'], 30, "\n", true);
    $ls = array_slice(explode("\n", $lineas), 0, 3);
    $t = '';
    foreach ($ls as $i => $l) $t .= '<text x="40" y="' . (96 + $i * 44) . '" font-size="36" font-weight="700" fill="#14201a">' . svg_esc($l) . '</text>';
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 420" width="800" height="420"><title>' . svg_esc('Precio de ' . $p['nombre']) . '</title>'
        . '<rect width="800" height="420" fill="#f6f3ea"/><rect x="0" y="0" width="800" height="18" fill="#0b4d36"/>'
        . '<g font-family="system-ui,Segoe UI,Roboto,sans-serif">' . $t
        . '<rect x="40" y="250" width="420" height="130" rx="10" fill="#ffd23f"/><text x="64" y="285" font-size="20" font-weight="700" fill="#14201a">MEJOR PRECIO · ' . svg_esc(mb_strtoupper(cadena_nombre($D, $mb[0]), 'UTF-8')) . '</text>'
        . '<text x="64" y="356" font-size="64" font-weight="800" fill="#14201a">' . svg_esc(pesos($mb[1])) . '</text>'
        . '<text x="760" y="372" text-anchor="end" font-size="22" font-weight="700" fill="#0b4d36">ofertometro.com.ar</text></g></svg>';
    escribir_archivo(cfg('salida') . '/img/producto/' . $p['slug'] . '.svg', $svg);
    $GLOBALS['IMGS_PAGINA'][] = ['/img/producto/' . $p['slug'] . '.svg', 'Precio de ' . $p['nombre']];
}
