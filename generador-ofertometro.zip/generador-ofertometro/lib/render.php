<?php
// Registro de páginas, publicación gradual y plantilla HTML.

$GLOBALS['PAGINAS'] = [];
$GLOBALS['PUBLICADAS'] = [];
$GLOBALS['ARCHIVOS_GENERADOS'] = [];

/**
 * Registra una página. $prio 0 = sale el primer día. Cuanto más alto, más tarde entra.
 * $fn devuelve el array de la página (ver pagina_html).
 */
function registrar($path, $prio, $seccion, $fn)
{
    $GLOBALS['PAGINAS'][$path] = ['prio' => $prio, 'seccion' => $seccion, 'fn' => $fn];
}

function publicada($path)
{
    return isset($GLOBALS['PUBLICADAS'][$path]);
}

// Decide qué páginas están publicadas hoy (núcleo + las que ya salieron + el cupo diario)
function calcular_publicadas($todo = false)
{
    $ruta = cfg('datos') . '/publicadas.json';
    $pub = leer_json($ruta, []);
    $hoy = hoy();
    $reg = $GLOBALS['PAGINAS'];
    foreach ($reg as $path => $p) {
        if ($p['prio'] === 0 && !isset($pub[$path])) $pub[$path] = $hoy;
    }
    $nuevas_hoy = 0;
    foreach ($pub as $path => $f) {
        if ($f === $hoy && isset($reg[$path]) && $reg[$path]['prio'] > 0) $nuevas_hoy++;
    }
    $pendientes = array_filter(array_keys($reg), function ($p) use ($pub) { return !isset($pub[$p]); });
    usort($pendientes, function ($a, $b) use ($reg) {
        return $reg[$a]['prio'] === $reg[$b]['prio'] ? strcmp($a, $b) : $reg[$a]['prio'] - $reg[$b]['prio'];
    });
    $cupo = $todo ? count($pendientes) : max(0, cfg('paginas_nuevas_por_dia', 3) - $nuevas_hoy);
    foreach (array_slice($pendientes, 0, $cupo) as $path) $pub[$path] = $hoy;
    guardar_json($ruta, $pub);
    // Sólo cuentan las que existen en el registro actual
    $GLOBALS['PUBLICADAS'] = array_intersect_key($pub, $reg);
    return count($pendientes) - $cupo;
}

// Enlace interno: si la página destino todavía no se publicó, queda como texto (nunca un 404)
function enlace($path, $texto, $clase = '')
{
    if (!publicada($path)) return e($texto);
    return '<a href="' . e($path) . '"' . ($clase ? ' class="' . e($clase) . '"' : '') . '>' . e($texto) . '</a>';
}

function url_abs($path)
{
    return rtrim(cfg('sitio_url'), '/') . $path;
}

// ---------- Componentes ----------

function avatar($nombre, $slug)
{
    // Se incrusta como data URI: cero pedidos extra al servidor aunque la tabla tenga 30 bancos
    static $cache = [];
    if (!isset($cache[$slug])) {
        $palabras = preg_split('/\s+/', preg_replace('/^(Banco|Grupo)\s+(de\s+|del\s+)?/iu', '', $nombre));
        $ini = '';
        foreach (array_slice($palabras, 0, 2) as $w) $ini .= function_exists('mb_substr') ? mb_substr($w, 0, 1, 'UTF-8') : substr($w, 0, 1);
        $ini = function_exists('mb_strtoupper') ? mb_strtoupper($ini, 'UTF-8') : strtoupper($ini);
        $colores = ['#0a7a5a', '#1d4ed8', '#7c3aed', '#b45309', '#be123c', '#0f766e', '#4338ca', '#a16207', '#15803d', '#9d174d'];
        $c = $colores[abs(crc32($slug)) % count($colores)];
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="40" height="40"><title>' . svg_esc($nombre) . '</title>'
            . '<rect width="40" height="40" rx="10" fill="' . $c . '"/><text x="20" y="25.5" text-anchor="middle" font-family="system-ui,Segoe UI,Roboto,sans-serif" font-size="15" font-weight="700" fill="#fff">' . svg_esc($ini) . '</text></svg>';
        $cache[$slug] = 'data:image/svg+xml,' . rawurlencode($svg);
    }
    return '<img class="avatar" src="' . $cache[$slug] . '" alt="' . e($nombre) . '" title="' . e($nombre) . '" width="28" height="28" loading="lazy">';
}

function entidad_celda($nombre, $slug, $path = null)
{
    return '<span class="entidad">' . avatar($nombre, $slug) . ' ' . ($path ? enlace($path, $nombre) : e($nombre)) . '</span>';
}

/**
 * Tabla. $filas = lista de arrays de celdas en HTML. $destacar = índice de fila a resaltar.
 * $num = índices de columnas numéricas (alineadas a la derecha).
 */
function tabla($encabezados, $filas, $num = [], $destacar = null, $titulo = '')
{
    $h = '<div class="tabla-scroll"><table>';
    if ($titulo) $h .= '<caption>' . e($titulo) . '</caption>';
    $h .= '<thead><tr>';
    foreach ($encabezados as $i => $t) $h .= '<th scope="col"' . (in_array($i, $num) ? ' class="n"' : '') . '>' . e($t) . '</th>';
    $h .= '</tr></thead><tbody>';
    foreach ($filas as $k => $f) {
        $attr = $f['_attr'] ?? '';
        unset($f['_attr']);
        $h .= '<tr' . ($destacar === $k ? ' class="destacada"' : '') . ($attr ? ' ' . $attr : '') . '>';
        foreach ($f as $i => $celda) $h .= '<td' . (in_array($i, $num) ? ' class="n"' : '') . '>' . $celda . '</td>';
        $h .= '</tr>';
    }
    return $h . '</tbody></table></div>';
}

function datos_clave($items)
{
    $h = '<div class="claves">';
    foreach ($items as $it) {
        if ($it[0] === '') continue;
        $h .= '<div class="clave" data-clave><span class="clave-etq">' . e($it[0]) . '</span><strong class="clave-val">' . $it[1] . '</strong>'
            . (!empty($it[2]) ? '<span class="clave-nota">' . $it[2] . '</span>' : '') . '</div>';
    }
    return $h . '</div>';
}

function aviso($html, $tipo = 'info')
{
    return '<div class="aviso aviso-' . $tipo . '">' . $html . '</div>';
}

function anuncio($pos)
{
    $cliente = cfg('adsense_client');
    $slots = cfg('adsense_slots', []);
    if (!$cliente || empty($slots[$pos])) return '';
    return '<div class="anuncio" aria-label="Publicidad"><ins class="adsbygoogle" style="display:block" data-ad-client="' . e($cliente)
        . '" data-ad-slot="' . e($slots[$pos]) . '" data-ad-format="auto" data-full-width-responsive="true"></ins>'
        . '<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></div>';
}

function datos_js($id, $datos)
{
    return '<script type="application/json" id="' . e($id) . '">' . json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>';
}

function enlaces_relacionados($items)
{
    $li = '';
    foreach ($items as $it) {
        if (publicada($it[0])) $li .= '<li>' . enlace($it[0], $it[1]) . '</li>';
    }
    return $li ? '<nav class="relacionados" aria-label="Páginas relacionadas"><h2>También te puede servir</h2><ul>' . $li . '</ul></nav>' : '';
}

function sin_historial_aun($desde)
{
    return aviso('Empezamos a registrar este dato día por día el ' . e(fecha_larga($desde, false)) . '. El gráfico de evolución aparece cuando juntamos al menos una semana de datos.');
}

// ---------- Plantilla ----------

// Si el título pasa de 60 caracteres, usa la versión corta
function titulo_corto($largo, $corto)
{
    $n = function_exists('mb_strlen') ? mb_strlen($largo, 'UTF-8') : strlen($largo);
    return $n > 60 ? $corto : $largo;
}

function logo_imgs($title, $lazy = false)
{
    $n = e(cfg('sitio_nombre'));
    $a = 'width="' . logo_ancho() . '" height="36"' . ($lazy ? ' loading="lazy"' : '');
    // En la cabecera el logo va incrustado (se ve al instante); en el pie se carga diferido
    $claro = $lazy ? '/img/logo.svg' : 'data:image/svg+xml,' . rawurlencode(logo_svg());
    $oscuro = $lazy ? '/img/logo-oscuro.svg' : 'data:image/svg+xml,' . rawurlencode(logo_svg(true));
    return '<img class="logo-claro" src="' . $claro . '" alt="' . $n . '" title="' . e($title) . '" ' . $a . '>'
        . '<img class="logo-oscuro" src="' . $oscuro . '" alt="' . $n . '" title="' . e($title) . '" ' . $a . '>';
}

// CSS minificado e incrustado en cada página: evita un pedido que bloquea el dibujado
function css_en_linea()
{
    static $css = null;
    if ($css === null) {
        $css = file_get_contents(dirname(__DIR__) . '/assets/estilos.css');
        $css = preg_replace('#/\*.*?\*/#s', '', $css);
        $css = preg_replace('/\s*\n\s*/', '', $css);
        $css = str_replace('</', '<\/', $css);
    }
    return $css;
}

// Google muestra ~140 caracteres de descripción: si se pasa, se corta en la última oración completa
function desc_ajustada($d)
{
    $len = function ($x) { return function_exists('mb_strlen') ? mb_strlen($x, 'UTF-8') : strlen($x); };
    if ($len($d) <= 158) return $d;
    $cortada = function_exists('mb_substr') ? mb_substr($d, 0, 156, 'UTF-8') : substr($d, 0, 156);
    $pos = strrpos($cortada, '. ');
    if ($pos !== false && $len(substr($cortada, 0, $pos + 1)) >= 120) return substr($cortada, 0, $pos + 1);
    $pos = strrpos($cortada, ' ');
    return rtrim(substr($cortada, 0, $pos), ' ,;:') . '…';
}

// Agrega " | Marca" al título si entra en 60 caracteres (lo que Google muestra sin cortar)
function titulo_con_marca($t)
{
    $marca = cfg('sitio_nombre');
    if (strpos($t, $marca) !== false) return $t;
    $largo = function_exists('mb_strlen') ? mb_strlen($t . ' | ' . $marca, 'UTF-8') : strlen($t . ' | ' . $marca);
    return $largo <= 60 ? $t . ' | ' . $marca : $t;
}

function boton_tema()
{
    return '<button class="tema" type="button" aria-label="Cambiar entre tema claro y oscuro" title="Tema claro / oscuro">'
        . '<svg class="ico-luna" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>'
        . '<svg class="ico-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></button>';
}

function logo_ancho()
{
    if (cfg('logo_ancho')) return cfg('logo_ancho');
    $n = cfg('sitio_nombre');
    return 48 + (int) ceil((function_exists('mb_strlen') ? mb_strlen($n, 'UTF-8') : strlen($n)) * 11.2);
}

function menu_principal()
{
    return cfg('menu', []);
}

/**
 * $p: path, title, h1, desc, cuerpo, migas [[texto, path]], faqs [[preg, resp]], fuente, js (bool), tipo
 */
function pagina_html($p)
{
    $nombre = cfg('sitio_nombre');
    $canon = url_abs($p['path']);
    $titulo = titulo_con_marca($p['title']);
    $desc = desc_ajustada($p['desc']);
    $ahora = date('c');

    // Datos estructurados
    $grafo = [];
    $migas = array_merge([[$nombre, '/']], $p['migas'] ?? []);
    if ($p['path'] !== '/') $migas[] = [$p['h1'], $p['path']];
    $items = [];
    foreach ($migas as $i => $m) $items[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $m[0], 'item' => url_abs($m[1])];
    $grafo[] = ['@type' => 'BreadcrumbList', 'itemListElement' => $items];
    $nota = $p['noticia'] ?? null;
    $grafo[] = ['@type' => 'WebPage', '@id' => $canon, 'url' => $canon, 'name' => $titulo, 'description' => $desc,
        'inLanguage' => 'es-AR', 'dateModified' => $nota ? $nota['modificado'] : $ahora, 'datePublished' => $nota ? $nota['publicado'] : ($p['publicada'] ?? hoy()), 'isPartOf' => ['@id' => url_abs('/#sitio')]];
    if ($nota) {
        $org = ['@type' => 'Organization', 'name' => $nombre, 'url' => url_abs('/'), 'logo' => ['@type' => 'ImageObject', 'url' => url_abs('/img/logo.png')]];
        $img = !empty($GLOBALS['IMGS_PAGINA'][0][0]) ? url_abs($GLOBALS['IMGS_PAGINA'][0][0]) : url_abs('/img/og.png');
        $grafo[] = ['@type' => 'NewsArticle', 'headline' => $p['h1'], 'description' => $desc, 'mainEntityOfPage' => $canon, 'inLanguage' => 'es-AR',
            'datePublished' => $nota['publicado'], 'dateModified' => $nota['modificado'], 'articleSection' => $nota['seccion'],
            'image' => [$img], 'author' => $org, 'publisher' => $org];
    }
    if ($p['path'] === '/') {
        $grafo[] = ['@type' => 'WebSite', '@id' => url_abs('/#sitio'), 'url' => url_abs('/'), 'name' => $nombre, 'inLanguage' => 'es-AR',
            'publisher' => ['@id' => url_abs('/#organizacion')]];
        $grafo[] = ['@type' => 'Organization', '@id' => url_abs('/#organizacion'), 'name' => $nombre, 'url' => url_abs('/'),
            'logo' => url_abs('/img/logo.png')];
    }
    if (!empty($p['schema_extra'])) foreach ($p['schema_extra'] as $x) $grafo[] = $x;
    if (!empty($p['faqs'])) {
        $q = [];
        foreach ($p['faqs'] as $f) $q[] = ['@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => strip_tags($f[1])]];
        $grafo[] = ['@type' => 'FAQPage', 'mainEntity' => $q];
    }
    $schema = json_encode(['@context' => 'https://schema.org', '@graph' => $grafo], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG);

    $v = date('YmdH');
    $h = '<!doctype html><html lang="es-AR"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . e($titulo) . '</title>'
        . '<meta name="description" content="' . e($desc) . '">'
        . (empty($p['noindex']) ? '<link rel="canonical" href="' . e($canon) . '"><link rel="alternate" hreflang="es-AR" href="' . e($canon) . '"><meta name="robots" content="index,follow,max-image-preview:large">' : '<meta name="robots" content="noindex,follow">')
        . '<meta property="og:type" content="' . ($nota ? 'article' : 'website') . '"><meta property="og:locale" content="es_AR">'
        . ($nota ? '<meta property="article:published_time" content="' . e($nota['publicado']) . '"><meta property="article:modified_time" content="' . e($nota['modificado']) . '"><meta property="article:section" content="' . e($nota['seccion']) . '">' : '')
        . '<meta property="og:site_name" content="' . e($nombre) . '">'
        . '<meta property="og:title" content="' . e($titulo) . '"><meta property="og:description" content="' . e($desc) . '">'
        . '<meta property="og:url" content="' . e($canon) . '"><meta property="og:image" content="' . e(url_abs('/img/og.png')) . '">'
        . '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="' . e($nombre . ' — ' . cfg('sitio_lema')) . '">'
        . '<meta name="twitter:card" content="summary_large_image">'
        . '<meta name="color-scheme" content="light dark"><meta name="theme-color" content="' . e(cfg('color_tema', '#0a3d91')) . '">'
        . '<script>try{var t=localStorage.getItem("tema");if(t==="claro"||t==="oscuro")document.documentElement.setAttribute("data-tema",t)}catch(e){}</script>'
        . '<link rel="icon" href="/favicon.ico" sizes="48x48"><link rel="icon" href="/favicon.svg" type="image/svg+xml">'
        . '<link rel="apple-touch-icon" href="/apple-touch-icon.png"><link rel="manifest" href="/site.webmanifest">'
        . '<meta name="apple-mobile-web-app-title" content="' . e($nombre) . '"><meta name="application-name" content="' . e($nombre) . '">'
        . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
        . '<link rel="stylesheet" href="' . e(cfg('fuentes_css')) . '">'
        . '<style>' . css_en_linea() . '</style>';
    if (cfg('google_site_verification')) $h .= '<meta name="google-site-verification" content="' . e(cfg('google_site_verification')) . '">';
    if (cfg('adsense_client')) {
        $h .= '<meta name="google-adsense-account" content="' . e(cfg('adsense_client')) . '">'
            . '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . e(cfg('adsense_client')) . '" crossorigin="anonymous"></script>';
    }
    if (cfg('ga4_id')) {
        $g = e(cfg('ga4_id'));
        $h .= '<script async src="https://www.googletagmanager.com/gtag/js?id=' . $g . '"></script>'
            . '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("js",new Date());gtag("config","' . $g . '");</script>';
    }
    $h .= '<script type="application/ld+json">' . $schema . '</script></head><body>';

    // Cabecera
    $h .= '<header class="cabecera"><div class="contenedor cab-int">'
        . '<a class="logo" href="/">' . logo_imgs($nombre . ' — Inicio') . '</a>'
        . '<nav class="menu" aria-label="Secciones"><ul>';
    foreach (menu_principal() as $path => $txt) {
        if (!publicada($path)) continue;
        $activa = $p['path'] === $path || ($path !== '/' && strpos($p['path'], $path) === 0);
        $h .= '<li><a href="' . $path . '"' . ($activa ? ' aria-current="page"' : '') . '>' . e($txt) . '</a></li>';
    }
    $h .= '</ul></nav>' . boton_tema() . '</div></header>';

    if (!empty($p['hero'])) $h .= '<section class="hero"><div class="contenedor">' . $p['hero'] . '</div></section>';
    if (!empty($p['cabeza'])) $h .= '<section class="cabeza"><div class="contenedor">' . $p['cabeza'] . '</div></section>';
    // Migas de pan
    $h .= '<main class="contenedor">';
    if ($p['path'] !== '/') {
        $h .= '<nav class="migas" aria-label="Ruta"><ol>';
        foreach ($migas as $i => $m) {
            $h .= $i === count($migas) - 1 ? '<li aria-current="page">' . e($m[0]) . '</li>' : '<li><a href="' . e($m[1]) . '">' . e($m[0]) . '</a></li>';
        }
        $h .= '</ol></nav>';
    }
    $h .= '<article>' . (!empty($p['encabezado']) ? $p['encabezado'] : (empty($p['hero']) && empty($p['cabeza']) ? '<h1>' . e($p['h1']) . '</h1>' : ''));
    if (!empty($p['hero']) || !empty($p['cabeza'])) {
    } elseif ($nota) {
        $h .= '<p class="actualizado">Publicado el <time datetime="' . e($nota['publicado']) . '">' . e(noticia_fecha_txt($nota['publicado'])) . '</time> · Redacción ' . e($nombre)
            . ($nota['modificado'] !== $nota['publicado'] ? ' · Actualizado: ' . e(noticia_fecha_txt($nota['modificado'])) : '') . '</p>';
    } else {
        $h .= !empty($GLOBALS['FECHA_DATOS']) ? '<p class="actualizado">Precios del <time datetime="' . e($GLOBALS['FECHA_DATOS']) . '">' . e(fecha_larga($GLOBALS['FECHA_DATOS'])) . '</time>'
            . (!empty($p['fuente']) ? ' · Fuente: ' . e($p['fuente']) : '') . '</p>' : '<p class="actualizado">Actualizado el <time datetime="' . e(date('c')) . '">' . e(fecha_larga(hoy())) . ' a las ' . e(hora_actual()) . ' h</time>'
            . (!empty($p['fuente']) ? ' · Fuente: ' . e($p['fuente']) : '') . '</p>';
    }
    if (!empty($p['prov'])) $h .= barra_provincia($p['prov']);
    $h .= $p['cuerpo'];
    foreach (cfg('referidos', []) as $ref_k => $ref) {
        $ok = false;
        foreach ($ref['paginas'] ?? [] as $re) if (preg_match($re, $p['path'])) $ok = true;
        if (!$ok || empty($ref['url']) || (!empty($ref['vence']) && hoy() > $ref['vence'])) continue;
        $h .= '<aside class="referido" aria-label="Enlace de referido"><div><strong>' . e($ref['titulo']) . '</strong><p>' . e($ref['texto']) . '</p>'
            . '<p class="nota">Enlace de referido: si abrís tu cuenta con este link, ' . e($nombre) . ' puede recibir una recompensa. No cambia los datos ni el orden de nuestros rankings.</p></div>'
            . '<a class="boton-ref" href="/ir/' . e($ref_k) . '/" rel="sponsored nofollow noopener" target="_blank">' . e($ref['boton']) . '</a></aside>';
        break;
    }
    if (empty($p['sin_aviso_legal'])) {
        $h .= '<aside class="aviso aviso-legal" role="note"><strong>Importante:</strong> ' . cfg('aviso_legal') . ' ' . (publicada('/terminos/') ? '<a href="/terminos/">Más información</a>.' : '') . '</aside>';
    }
    if (!empty($p['faqs'])) {
        $h .= '<section class="faq"><h2>Preguntas frecuentes</h2>';
        foreach ($p['faqs'] as $f) $h .= '<details><summary>' . e($f[0]) . '</summary><div>' . $f[1] . '</div></details>';
        $h .= '</section>';
    }
    $h .= anuncio('abajo');
    $h .= '</article></main>';

    // Pie
    $h .= '<footer class="pie"><div class="contenedor pie-int"><div>' . logo_imgs($nombre, true)
        . '<p>' . e(cfg('sitio_lema')) . '.</p><p class="legal">' . cfg('pie_legal') . '</p></div>'
        . '<nav aria-label="Secciones del sitio"><h2>Secciones</h2><ul>';
    foreach (menu_principal() as $path => $txt) if (publicada($path)) $h .= '<li><a href="' . $path . '">' . e($txt) . '</a></li>';
    $h .= '</ul></nav><nav aria-label="Herramientas"><h2>Herramientas</h2><ul>';
    foreach (cfg('menu_herramientas', []) as $path => $txt) {
        if (publicada($path)) $h .= '<li><a href="' . $path . '">' . e($txt) . '</a></li>';
    }
    $h .= '</ul></nav><nav aria-label="Institucional"><h2>' . e($nombre) . '</h2><ul>';
    foreach (['/acerca/' => 'Quiénes somos', '/fuentes/' => 'Fuentes de los datos', '/contacto/' => 'Contacto', '/privacidad/' => 'Privacidad', '/terminos/' => 'Términos de uso', '/mapa-del-sitio/' => 'Mapa del sitio'] as $path => $txt) {
        if (publicada($path)) $h .= '<li><a href="' . $path . '">' . e($txt) . '</a></li>';
    }
    $h .= '<li><a href="/sitemap.xml">Sitemap XML</a></li>';
    $h .= '</ul></nav></div><p class="contenedor copy">© ' . date('Y') . ' ' . e($nombre) . '. ' . cfg('pie_datos') . '</p></footer>';
    $h .= '<script>(function(){var b=document.querySelector(".tema");if(!b)return;b.addEventListener("click",function(){var r=document.documentElement,a=r.getAttribute("data-tema")||(matchMedia("(prefers-color-scheme: dark)").matches?"oscuro":"claro"),n=a==="oscuro"?"claro":"oscuro";r.setAttribute("data-tema",n);try{localStorage.setItem("tema",n)}catch(e){}})})();</script>';
    if (!empty($p['js']) || !empty($p['prov'])) $h .= '<script src="/app.js?v=' . $v . '" defer></script>';
    return $h . '</body></html>';
}
