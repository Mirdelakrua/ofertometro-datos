<?php
// Gráficos SVG generados en el servidor (sin librerías). Se guardan como archivos en /img/graficos/
// y se insertan con <img> con alt y title.

const COLOR_ACENTO = '#0b6b47';
const COLOR_TEXTO = '#7b8899';
const COLOR_GRILLA = '#8b98a8';

function svg_esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function valores_redondos($min, $max, $cant = 4)
{
    $rango = $max - $min;
    if ($rango <= 0) $rango = abs($max) ?: 1;
    $paso_bruto = $rango / $cant;
    $mag = pow(10, floor(log10($paso_bruto)));
    $norm = $paso_bruto / $mag;
    $paso = ($norm <= 1 ? 1 : ($norm <= 2 ? 2 : ($norm <= 2.5 ? 2.5 : ($norm <= 5 ? 5 : 10)))) * $mag;
    $ini = floor($min / $paso) * $paso;
    $fin = ceil($max / $paso) * $paso;
    $out = [];
    for ($v = $ini; $v <= $fin + $paso / 2; $v += $paso) $out[] = round($v, 10);
    return $out;
}

/**
 * Gráfico de línea. $puntos = [[fecha 'Y-m-d', valor], ...]
 * $fmt = función que da formato a los valores del eje Y.
 */
function svg_linea($puntos, $titulo, $descripcion, $fmt)
{
    $W = 720; $H = 290; $L = 70; $R = 24; $T = 32; $B = 40;
    $n = count($puntos);
    $vals = array_column($puntos, 1);
    $min = min($vals); $max = max($vals);
    if ($max - $min < 1e-9) { $min -= abs($min) * 0.02 + 0.0001; $max += abs($max) * 0.02 + 0.0001; }
    $ticks = valores_redondos($min, $max, 4);
    $ymin = min($ticks); $ymax = max($ticks);
    $t0 = strtotime($puntos[0][0]); $t1 = strtotime($puntos[$n - 1][0]);
    $span = max(1, $t1 - $t0);
    $x = function ($f) use ($t0, $span, $W, $L, $R) { return $L + (strtotime($f) - $t0) / $span * ($W - $L - $R); };
    $y = function ($v) use ($ymin, $ymax, $H, $T, $B) { return $T + (1 - ($v - $ymin) / ($ymax - $ymin)) * ($H - $T - $B); };

    $s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $W . ' ' . $H . '" width="' . $W . '" height="' . $H . '" role="img">';
    $s .= '<title>' . svg_esc($titulo) . '</title><desc>' . svg_esc($descripcion) . '</desc>';
        $s .= '<g font-family="system-ui,-apple-system,Segoe UI,Roboto,sans-serif" font-size="12" fill="' . COLOR_TEXTO . '">';
    foreach ($ticks as $tv) {
        $yy = round($y($tv), 1);
        $s .= '<line x1="' . $L . '" x2="' . ($W - $R) . '" y1="' . $yy . '" y2="' . $yy . '" stroke="' . COLOR_GRILLA . '" stroke-opacity="0.3"/>';
        $s .= '<text x="' . ($L - 8) . '" y="' . ($yy + 4) . '" text-anchor="end">' . svg_esc($fmt($tv)) . '</text>';
    }
    // Etiquetas de fechas
    $largo = ($t1 - $t0) > 150 * 86400;
    $idxs = array_unique([0, (int) floor(($n - 1) / 2), $n - 1]);
    foreach ($idxs as $k => $i) {
        $f = $puntos[$i][0];
        $etq = $largo ? substr(nombre_mes(date('n', strtotime($f))), 0, 3) . ' ' . date('y', strtotime($f)) : date('d/m', strtotime($f));
        $anchor = $i == 0 ? 'start' : ($i == $n - 1 ? 'end' : 'middle');
        $s .= '<text x="' . round($x($f), 1) . '" y="' . ($H - 14) . '" text-anchor="' . $anchor . '">' . svg_esc($etq) . '</text>';
    }
    // Área y línea
    $linea = [];
    foreach ($puntos as $p) $linea[] = round($x($p[0]), 1) . ',' . round($y($p[1]), 1);
    $base = round($y($ymin), 1);
    $s .= '<polygon points="' . round($x($puntos[0][0]), 1) . ',' . $base . ' ' . implode(' ', $linea) . ' ' . round($x($puntos[$n - 1][0]), 1) . ',' . $base . '" fill="' . COLOR_ACENTO . '" fill-opacity="0.08"/>';
    $s .= '<polyline points="' . implode(' ', $linea) . '" fill="none" stroke="' . COLOR_ACENTO . '" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>';
    $ul = $puntos[$n - 1];
    $ux = round($x($ul[0]), 1); $uy = round($y($ul[1]), 1);
    $s .= '<circle cx="' . $ux . '" cy="' . $uy . '" r="4.5" fill="' . COLOR_ACENTO . '"/>';
    $s .= '<text x="' . ($W - $R) . '" y="14" text-anchor="end" font-weight="700" font-size="13" fill="' . COLOR_ACENTO . '">Último: ' . svg_esc($fmt($ul[1])) . '</text>';
    $s .= '</g></svg>';
    return $s;
}

/**
 * Barras horizontales. $items = [[etiqueta, valor, destacado(bool)], ...]
 */
function svg_barras($items, $titulo, $descripcion, $fmt)
{
    $W = 720; $fila = 30; $L = 190; $R = 80; $T = 10;
    $H = $T + count($items) * $fila + 10;
    $max = max(array_map(function ($i) { return $i[1]; }, $items)) ?: 1;
    $s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $W . ' ' . $H . '" width="' . $W . '" height="' . $H . '" role="img">';
    $s .= '<title>' . svg_esc($titulo) . '</title><desc>' . svg_esc($descripcion) . '</desc>';
        $s .= '<g font-family="system-ui,-apple-system,Segoe UI,Roboto,sans-serif" font-size="13">';
    foreach ($items as $k => $it) {
        $yy = $T + $k * $fila;
        $ancho = max(2, ($it[1] / $max) * ($W - $L - $R));
        $color = !empty($it[2]) ? COLOR_ACENTO : '#8b98a8';
        $s .= '<text x="' . ($L - 10) . '" y="' . ($yy + 19) . '" text-anchor="end" fill="' . COLOR_TEXTO . '">' . svg_esc($it[0]) . '</text>';
        $s .= '<rect x="' . $L . '" y="' . ($yy + 5) . '" width="' . round($ancho, 1) . '" height="20" rx="4" fill="' . $color . '"/>';
        $s .= '<text x="' . round($L + $ancho + 8, 1) . '" y="' . ($yy + 19) . '" fill="' . COLOR_TEXTO . '" font-weight="700">' . svg_esc($fmt($it[1])) . '</text>';
    }
    $s .= '</g></svg>';
    return $s;
}

// Guarda el SVG y devuelve el <img> listo para insertar (con alt y title)
function grafico($nombre_archivo, $svg, $alt, $titulo)
{
    $ruta = '/img/graficos/' . $nombre_archivo . '.svg';
    escribir_archivo(cfg('salida') . $ruta, $svg);
    preg_match('/viewBox="0 0 (\d+) (\d+)"/', $svg, $m);
    $GLOBALS['ARCHIVOS_GENERADOS'][$ruta] = true;
    $GLOBALS['IMGS_PAGINA'][] = [$ruta, $titulo];
    return '<figure class="grafico"><img src="' . $ruta . '?v=' . date('Ymd') . '" alt="' . e($alt) . '" title="' . e($titulo) . '" width="' . $m[1] . '" height="' . $m[2] . '" loading="lazy" decoding="async"><figcaption>' . e($titulo) . '</figcaption></figure>';
}
