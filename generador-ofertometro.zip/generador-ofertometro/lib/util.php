<?php
// Funciones generales: configuración, formatos, fechas y archivos.

function cfg($clave, $defecto = null)
{
    return array_key_exists($clave, $GLOBALS['CFG']) ? $GLOBALS['CFG'][$clave] : $defecto;
}

function e($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function slug($s)
{
    $s = trim((string) $s);
    $mapa = ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
        'Á' => 'a', 'É' => 'e', 'Í' => 'i', 'Ó' => 'o', 'Ú' => 'u', 'Ü' => 'u', 'Ñ' => 'n',
        '$' => '', '°' => '', 'º' => ''];
    $s = strtr($s, $mapa);
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-');
}

function limpiar_espacios($s)
{
    return trim(preg_replace('/\s+/u', ' ', (string) $s));
}

// ---------- Números ----------

function num($n, $dec = 0)
{
    return number_format((float) $n, $dec, ',', '.');
}

// Fracción a porcentaje: 0.1925 -> "19,25%"
function pct($fraccion, $dec = 2)
{
    if ($fraccion === null) return '—';
    return num($fraccion * 100, $dec) . '%';
}

// Valor que ya viene en porcentaje: 2.1 -> "2,1%"
function pctv($valor, $dec = 1)
{
    if ($valor === null) return '—';
    return num($valor, $dec) . '%';
}

function pesos($n, $dec = 0)
{
    if ($n === null) return '—';
    $signo = $n < 0 ? '-' : '';
    return $signo . '$' . num(abs($n), $dec);
}

function usd($n, $dec = 2)
{
    if ($n === null) return '—';
    return 'US$' . num($n, $dec);
}

// Puntos porcentuales entre dos fracciones: 0.235 - 0.19 -> "4,50 puntos"
function puntos($dif, $dec = 2)
{
    return num(abs($dif) * 100, $dec) . ' ' . (abs(round($dif * 100, $dec)) == 1 ? 'punto' : 'puntos');
}

// 1000000 -> "1 millón", 500000 -> "500 mil", 2500000 -> "2,5 millones"
function monto_texto($n)
{
    if ($n >= 1000000) {
        $m = $n / 1000000;
        $txt = (floor($m) == $m) ? num($m) : num($m, 1);
        return $txt . ($m == 1 ? ' millón' : ' millones');
    }
    if ($n >= 1000) return num($n / 1000) . ' mil';
    return num($n);
}

// 1000000 -> "1-millon", 500000 -> "500-mil"
function monto_slug($n)
{
    return slug(monto_texto($n));
}

// ---------- Fechas ----------

function hoy()
{
    return date('Y-m-d');
}

function dias_entre($a, $b)
{
    return (int) round((strtotime($b) - strtotime($a)) / 86400);
}

function sumar_dias($fecha, $dias)
{
    return date('Y-m-d', strtotime($fecha . ' ' . ($dias >= 0 ? '+' : '') . $dias . ' days'));
}

function nombre_mes($m)
{
    $meses = [1 => 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto',
        'septiembre', 'octubre', 'noviembre', 'diciembre'];
    return $meses[(int) $m];
}

function fecha_larga($ymd, $con_dia = true)
{
    $t = strtotime($ymd);
    $dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    $txt = date('j', $t) . ' de ' . nombre_mes(date('n', $t)) . ' de ' . date('Y', $t);
    return $con_dia ? $dias[(int) date('w', $t)] . ' ' . $txt : $txt;
}

function fecha_corta($ymd)
{
    return date('d/m/Y', strtotime($ymd));
}

function mes_anio($ymd)
{
    $t = strtotime($ymd);
    return nombre_mes(date('n', $t)) . ' ' . date('Y', $t);
}

function hora_actual()
{
    return date('H:i');
}

// ---------- Archivos ----------

function asegurar_carpeta($dir)
{
    if (!is_dir($dir)) mkdir($dir, 0755, true);
}

function escribir_archivo($ruta, $contenido)
{
    asegurar_carpeta(dirname($ruta));
    $tmp = $ruta . '.tmp' . getmypid();
    file_put_contents($tmp, $contenido);
    rename($tmp, $ruta);
}

function leer_json($ruta, $defecto = null)
{
    if (!is_file($ruta)) return $defecto;
    $d = json_decode(file_get_contents($ruta), true);
    return $d === null ? $defecto : $d;
}

function guardar_json($ruta, $datos)
{
    escribir_archivo($ruta, json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function registrar_log($msg)
{
    $ruta = cfg('datos') . '/registro.log';
    asegurar_carpeta(dirname($ruta));
    if (is_file($ruta) && filesize($ruta) > 512 * 1024) {
        @rename($ruta, $ruta . '.1');
    }
    $linea = '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL;
    file_put_contents($ruta, $linea, FILE_APPEND);
    if (PHP_SAPI === 'cli') echo $linea;
}

// ---------- Colecciones ----------

function ordenar_por(&$lista, $campo, $desc = true)
{
    usort($lista, function ($a, $b) use ($campo, $desc) {
        $va = $a[$campo];
        $vb = $b[$campo];
        if ($va == $vb) return 0;
        $r = ($va < $vb) ? -1 : 1;
        return $desc ? -$r : $r;
    });
}

function promedio($valores)
{
    $valores = array_values(array_filter($valores, function ($v) { return $v !== null; }));
    return count($valores) ? array_sum($valores) / count($valores) : null;
}

// Posición (1 = mejor) de un elemento en una lista ya ordenada
function posicion($lista, $campo, $valor)
{
    foreach ($lista as $i => $item) {
        if ($item[$campo] === $valor) return $i + 1;
    }
    return null;
}
