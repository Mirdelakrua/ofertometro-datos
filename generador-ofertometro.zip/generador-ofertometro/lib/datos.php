<?php
// Datos de precios: se bajan del repositorio público y se cargan en memoria con índices.

const ARCHIVOS_DATOS = ['meta.json', 'productos.json', 'cadenas.json', 'canasta.json', 'historial.json'];

function datos_dir()
{
    return cfg('datos') . '/sepa';
}

// Baja los JSON si pasaron N horas o si hay fecha nueva. Valida antes de reemplazar.
function datos_sincronizar()
{
    $dir = datos_dir();
    asegurar_carpeta($dir);
    $base = cfg('datos_remoto_url');
    $marca = cfg('datos') . '/ultima-sync.txt';
    if (!$base) return 'sin-url';
    if (!$GLOBALS['FORZAR'] && is_file($marca) && time() - filemtime($marca) < cfg('datos_cada_horas', 2) * 3600 && is_file($dir . '/productos.json')) return 'cache';
    @touch($marca);
    $ctx = stream_context_create(['http' => ['timeout' => 60, 'header' => "User-Agent: ofertometro-generador\r\n"]]);
    $meta = @file_get_contents($base . 'meta.json?t=' . time(), false, $ctx);
    $m = $meta ? json_decode($meta, true) : null;
    if (empty($m['fecha']) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $m['fecha'])) { registrar_log('Datos remotos: meta.json inválido'); return 'error'; }
    $local = leer_json($dir . '/meta.json', []);
    if (!$GLOBALS['FORZAR'] && ($local['fecha'] ?? '') === $m['fecha'] && ($local['generado'] ?? '') === ($m['generado'] ?? '')) return 'sin-cambios';
    $nuevos = ['meta.json' => $meta];
    foreach (ARCHIVOS_DATOS as $a) {
        if ($a === 'meta.json') continue;
        $txt = @file_get_contents($base . $a . '?t=' . time(), false, $ctx);
        $j = $txt ? json_decode($txt, true) : null;
        if (!is_array($j)) { registrar_log("Datos remotos: $a inválido, se mantiene lo anterior"); return 'error'; }
        if ($a === 'productos.json' && count($j) < 200) { registrar_log('Datos remotos: muy pocos productos (' . count($j) . '), se ignora'); return 'error'; }
        $nuevos[$a] = $txt;
    }
    foreach ($nuevos as $a => $txt) escribir_archivo($dir . '/' . $a, $txt);
    registrar_log('Datos actualizados al ' . $m['fecha'] . ' (' . ($m['productos'] ?? '?') . ' productos)');
    return 'nuevos';
}

function datos_cargar()
{
    $dir = datos_dir();
    $D = ['ok' => ['precios' => false]];
    foreach (ARCHIVOS_DATOS as $a) $D[basename($a, '.json')] = leer_json($dir . '/' . $a, []);
    if (empty($D['productos'])) return $D;
    $D['ok']['precios'] = true;
    // Índices
    $D['por_slug'] = []; $D['por_sub'] = []; $D['por_cat'] = [];
    foreach ($D['productos'] as $i => $p) {
        $D['por_slug'][$p['slug']] = $i;
        $D['por_sub'][$p['sub']][] = $i;
        $D['por_cat'][$p['cat']][$p['sub']] = true;
    }
    $GLOBALS['CAD_GRANDES'] = [];
    foreach ($D['cadenas'] as $sl => $c) if (($c['sucursales'] ?? 0) >= cfg('ranking_min_sucursales')) $GLOBALS['CAD_GRANDES'][$sl] = true;
    // Cadenas que compiten en rankings
    $D['ranking'] = [];
    foreach ($D['cadenas'] as $sl => $c) {
        if (($c['sucursales'] ?? 0) >= cfg('ranking_min_sucursales') && ($c['productos'] ?? 0) >= cfg('ranking_min_productos') && isset($c['indice'])) $D['ranking'][$sl] = $c['indice'];
    }
    asort($D['ranking']);
    return $D;
}

// ---------- Catálogo ----------

const CATEGORIAS = [
    'almacen' => ['nombre' => 'Almacén', 'desc' => 'aceite, arroz, fideos, yerba, azúcar, harina, café y todo lo de la alacena', 'ico' => 'almacen'],
    'lacteos' => ['nombre' => 'Lácteos', 'desc' => 'leche, yogur, manteca, queso y crema', 'ico' => 'lacteos'],
    'bebidas' => ['nombre' => 'Bebidas', 'desc' => 'gaseosas, agua, jugos, cerveza, vino y fernet', 'ico' => 'bebidas'],
    'limpieza' => ['nombre' => 'Limpieza', 'desc' => 'lavandina, detergente, jabón para ropa, suavizante y papel higiénico', 'ico' => 'limpieza'],
    'perfumeria' => ['nombre' => 'Perfumería', 'desc' => 'shampoo, desodorante, jabón, pasta dental, pañales y toallitas', 'ico' => 'perfumeria'],
];

function cat_nombre($c) { return CATEGORIAS[$c]['nombre'] ?? ucfirst($c); }
function sub_nombre($D, $s) { return $D['meta']['subcategorias'][$s] ?? ucfirst(str_replace('-', ' ', $s)); }
function cadena_nombre($D, $c) { return $D['cadenas'][$c]['nombre'] ?? ucfirst(str_replace('-', ' ', $c)); }
function prov_nombre($D, $pv) { return $D['meta']['provincias'][$pv] ?? $pv; }

function path_producto($p) { return '/precio/' . $p['slug'] . '/'; }
function path_cat($c) { return '/precios/' . $c . '/'; }
function path_sub($D, $s)
{
    foreach ($D['por_cat'] as $c => $subs) if (isset($subs[$s])) return '/precios/' . $c . '/' . $s . '/';
    return '/precios/';
}
function path_cadena($c) { return '/supermercados/' . $c . '/'; }
function path_ofertas_cadena($c) { return '/ofertas/' . $c . '/'; }
function path_prov($D, $pv) { return '/supermercado-mas-barato/' . slug(prov_nombre($D, $pv)) . '/'; }

function productos_de_sub($D, $s)
{
    $out = [];
    foreach ($D['por_sub'][$s] ?? [] as $i) $out[] = $D['productos'][$i];
    return $out;
}

// Cadena más barata de un producto: [slug, precio]
function mas_barata($p)
{
    // Sólo compiten las cadenas con 10 o más sucursales (las chicas se muestran en la tabla, pero no "ganan")
    $g = array_intersect_key($p['cad'], $GLOBALS['CAD_GRANDES'] ?? []);
    $pool = count($g) >= 3 ? $g : $p['cad'];
    $best = null;
    foreach ($pool as $c => $x) if ($best === null || $x['p'] < $best[1]) $best = [$c, $x['p']];
    return $best;
}

function mas_cara($p)
{
    $g = array_intersect_key($p['cad'], $GLOBALS['CAD_GRANDES'] ?? []);
    $pool = count($g) >= 3 ? $g : $p['cad'];
    $w = null;
    foreach ($pool as $c => $x) if ($w === null || $x['p'] > $w[1]) $w = [$c, $x['p']];
    return $w;
}

// Diferencia entre la más cara y la más barata, en fracción
function brecha($p)
{
    return $p['min'] > 0 ? ($p['max'] - $p['min']) / $p['min'] : 0;
}

// Ofertas vigentes de un producto: [[cadena, precio_promo, texto, precio_lista], ...] ordenadas por precio
function ofertas_producto($p)
{
    $o = [];
    foreach ($p['cad'] as $c => $x) {
        if (!empty($x['promo']) && promo_vigente($x['promo'])) $o[] = [$c, $x['promo']['p'], promo_texto($x['promo']['txt'], $x['promo']['hasta'] ?? ''), $x['p'], $x['promo']['n']];
    }
    usort($o, function ($a, $b) { return $a[1] <=> $b[1]; });
    return $o;
}

function promo_vigente($pr)
{
    return empty($pr['hasta']) || $pr['hasta'] >= hoy();
}

// "Promo A valida desde el 30/10/2026 hasta 11/11/2026" -> "Hasta el 11/11"
function promo_texto($t, $hasta = '')
{
    if ($hasta) return 'Vigente hasta el ' . date('j/n', strtotime($hasta));
    $t = limpiar_espacios($t);
    if (preg_match('#hasta (el )?(\d{1,2})/(\d{1,2})(/\d{2,4})?#i', $t, $m)) return 'Vigente hasta el ' . (int) $m[2] . '/' . (int) $m[3];
    if (preg_match('/^promo [a-z0-9]+$/i', $t)) return 'Precio promocional';
    return function_exists('mb_substr') ? mb_substr($t, 0, 70, 'UTF-8') : substr($t, 0, 70);
}

// Logo de cadena: monograma con color propio, incrustado (sin pedidos extra)
function marca_cadena($D, $c, $tam = 28)
{
    static $colores = ['coto' => '#c8102e', 'dia' => '#e30613', 'carrefour' => '#1e4fa0', 'carrefour-express' => '#1e4fa0', 'carrefour-market' => '#1e4fa0',
        'carrefour-maxi' => '#1e4fa0', 'jumbo' => '#009a44', 'disco' => '#d71920', 'vea' => '#e2231a', 'changomas' => '#00843d', 'hiperchangomas' => '#00843d',
        'la-anonima' => '#004b87', 'cooperativa-obrera' => '#e4002b', 'toledo' => '#f39200', 'deheza' => '#7a1f2b', 'mariano-max' => '#0067b1'];
    $nom = cadena_nombre($D, $c);
    $col = $colores[$c] ?? ['#0b6b47', '#7c3aed', '#b45309', '#be123c', '#0f766e', '#4338ca'][abs(crc32($c)) % 6];
    return avatar_color($nom, $c, $col, $tam);
}

function avatar_color($nombre, $slug, $color, $tam = 28)
{
    $limpio = preg_replace('/^(Carrefour|Supermercados?|Hipermercado)\s+/iu', '', $nombre);
    $pal = preg_split('/\s+/', $limpio);
    $ini = '';
    foreach (array_slice($pal, 0, 2) as $w) $ini .= mb_substr($w, 0, 1, 'UTF-8');
    if (mb_strlen($ini, 'UTF-8') < 2) $ini = mb_substr($limpio, 0, 2, 'UTF-8');
    $ini = mb_strtoupper(mb_substr($ini, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($ini, 1, 1, 'UTF-8');
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="40" height="40"><title>' . svg_esc($nombre) . '</title>'
        . '<rect width="40" height="40" rx="9" fill="' . $color . '"/><text x="20" y="26" text-anchor="middle" font-family="system-ui,Segoe UI,Roboto,sans-serif" font-size="16" font-weight="800" fill="#fff">' . svg_esc($ini) . '</text></svg>';
    return '<img class="avatar" src="data:image/svg+xml,' . rawurlencode($svg) . '" alt="Logo de ' . e($nombre) . '" title="' . e($nombre) . '" width="' . $tam . '" height="' . $tam . '" loading="lazy">';
}

function cadena_celda($D, $c, $link = true)
{
    $n = cadena_nombre($D, $c);
    return '<span class="entidad">' . marca_cadena($D, $c) . ' ' . ($link ? enlace(path_cadena($c), $n) : e($n)) . '</span>';
}

// Ícono simple de categoría (SVG en línea, decorativo con title)
function icono_cat($c)
{
    $paths = [
        'almacen' => '<path d="M7 9h18l-2 15H9z"/><path d="M11 9V7a5 5 0 0 1 10 0v2"/>',
        'lacteos' => '<path d="M11 4h10v4l3 4v15H8V12l3-4z"/><path d="M8 16h16"/>',
        'bebidas' => '<path d="M13 3h6v5l2 3v17h-10V11l2-3z"/><path d="M11 17h10"/>',
        'limpieza' => '<path d="M12 12h9l1 15H11z"/><path d="M14 12V7h4l4-3"/><path d="M18 7h2"/>',
        'perfumeria' => '<rect x="10" y="10" width="12" height="17" rx="3"/><path d="M13 10V6h6v4"/><path d="M16 15v6"/>',
    ];
    return '<svg class="ico-cat" viewBox="0 0 32 32" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" role="img" aria-label="' . e(cat_nombre($c)) . '"><title>' . e(cat_nombre($c)) . '</title>' . ($paths[$c] ?? '') . '</svg>';
}

// Etiqueta tipo góndola: el precio grande con centavos chicos
function precio_gondola($n, $clase = '')
{
    return '<span class="pg' . ($clase ? ' ' . $clase : '') . '"><span class="pg-s">$</span>' . num($n) . '</span>';
}

function historial_producto($D, $p)
{
    $h = $D['historial']['p'][$p['ean']] ?? [];
    ksort($h);
    $pts = [];
    foreach ($h as $f => $v) $pts[] = [$f, $v];
    return $pts;
}

function fecha_datos($D)
{
    return $D['meta']['fecha'] ?? hoy();
}

// ---------- Filtro por provincia ----------

// Barra "¿Dónde comprás?": la elección se guarda en el navegador y reordena las comparativas de la página.
// $modo: true (elige el visitante) o un código de provincia (página de una provincia: queda fija)
function barra_provincia($modo, $ir = false)
{
    $D = $GLOBALS['D'];
    $provs = [];
    foreach ($D['cadenas'] as $c) foreach ($c['prov'] as $pv => $n) $provs[$pv] = true;
    $nombres = [];
    foreach (array_keys($provs) as $pv) $nombres[$pv] = prov_nombre($D, $pv);
    asort($nombres);
    $fija = is_string($modo) ? $modo : '';
    $h = '<div class="barra-prov" data-barra-prov' . ($fija ? ' data-fija="' . e($fija) . '"' : '') . ($ir ? ' data-ir' : '') . '><label for="sel-prov"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>¿Dónde comprás?</label>'
        . '<select id="sel-prov" data-sel-prov><option value="">Todo el país</option>';
    foreach ($nombres as $pv => $n) $h .= '<option value="' . e($pv) . '"' . ($fija === $pv ? ' selected' : '') . '>' . e($n) . '</option>';
    $h .= '</select><select data-sel-ciudad aria-label="Ciudad" hidden><option value="">Toda la provincia</option></select><span class="bp-nota" data-bp-nota>' . ($fija ? 'Mostrando los supermercados de ' . e(prov_nombre($D, $fija)) : 'Elegí tu provincia y te mostramos solo los supermercados que tenés cerca.') . '</span></div>';
    return $h . datos_js('ofe-comun', datos_comunes_js($D));
}

function datos_comunes_js($D)
{
    static $j = null;
    if ($j !== null) return $j;
    $cad = [];
    foreach ($D['cadenas'] as $sl => $c) {
        preg_match('/src="([^"]+)"/', marca_cadena($D, $sl), $m);
        $cad[$sl] = [$c['nombre'], $m[1] ?? '', publicada(path_cadena($sl)) ? path_cadena($sl) : '', array_keys($c['prov']), (object) ($c['loc'] ?? [])];
    }
    $nom = [];
    foreach ($D['meta']['provincias'] ?? [] as $pv => $n) $nom[$pv] = [$n, isset($D['canasta']['provincias'][$pv]) && publicada(path_prov($D, $pv)) ? path_prov($D, $pv) : ''];
    return $j = ['cad' => $cad, 'prov' => $nom, 'rank' => $D['canasta']['provincias'] ?? [], 'loc' => (object) ($D['meta']['localidades'] ?? [])];
}

// Datos por provincia de un producto para las tablas de listado: {pv: [[cadena, precio], ...]} de menor a mayor
function pv_producto($p)
{
    $o = [];
    foreach ($p['prov'] ?? [] as $pv => $fila) {
        if (!$fila) continue;
        $o[$pv] = array_map(function ($x) { return [$x[0], $x[1]]; }, $fila);
    }
    return $o;
}
