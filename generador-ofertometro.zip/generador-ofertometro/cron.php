<?php
/*
 * GENERADOR DEL SITIO
 * Se ejecuta con el cron de cPanel (recomendado: cada 2 horas):
 *     /usr/local/bin/php /home/TU_USUARIO/generador/cron.php
 *
 * Opciones:
 *     --forzar   ignora la caché y vuelve a descargar todos los datos
 *     --todo     publica todas las páginas de una vez (sin publicación gradual)
 */

$GLOBALS['CFG'] = require __DIR__ . '/config.php';
// Para pruebas locales se pueden pisar rutas con variables de entorno
foreach (['MODO_PRUEBA' => 'modo_prueba', 'SALIDA' => 'salida', 'DATOS' => 'datos'] as $env => $k) {
    if (getenv($env)) $GLOBALS['CFG'][$k] = getenv($env);
}
date_default_timezone_set($GLOBALS['CFG']['zona_horaria']);
set_time_limit(600);
ini_set('memory_limit', '1024M');

foreach (['util', 'graficos', 'render', 'datos'] as $f) require __DIR__ . '/lib/' . $f . '.php';
foreach (['inicio', 'precios', 'cadenas', 'ranking'] as $f) require __DIR__ . '/secciones/' . $f . '.php';

$args = isset($argv) ? $argv : [];
$GLOBALS['FORZAR'] = in_array('--forzar', $args, true);
$todo = in_array('--todo', $args, true);

asegurar_carpeta(cfg('datos'));
asegurar_carpeta(cfg('salida'));
$lock = fopen(cfg('datos') . '/cron.lock', 'c');
if (!flock($lock, LOCK_EX | LOCK_NB)) {
    registrar_log('Ya hay una ejecución en curso, salgo.');
    exit(0);
}

$t0 = microtime(true);
$sync = datos_sincronizar();
$D = datos_cargar();
$GLOBALS['FECHA_DATOS'] = $D['meta']['fecha'] ?? '';
$GLOBALS['D'] = $D;
registrar_log('Datos: sync=' . $sync . ', fecha=' . ($D['meta']['fecha'] ?? '—') . ', productos=' . count($D['productos'] ?? []));
// Sin datos nuevos y con el sitio ya generado hoy, no hace falta rehacer todo
if ($sync !== 'nuevos' && !$GLOBALS['FORZAR'] && !$todo && is_file(cfg('datos') . '/ultima-generacion.txt')
    && trim(file_get_contents(cfg('datos') . '/ultima-generacion.txt')) === hoy() . '|' . ($D['meta']['generado'] ?? '')) {
    registrar_log('Sin cambios: nada que regenerar.');
    exit(0);
}

seccion_inicio($D);
seccion_precios($D);
seccion_cadenas($D);
seccion_ranking($D);
$pendientes = calcular_publicadas($todo);

// ---------- Archivos fijos ----------
$salida = cfg('salida');
foreach (['app.js', 'favicon.svg', 'favicon.ico', 'favicon-32.png', 'apple-touch-icon.png', 'icon-192.png', 'icon-512.png', 'img/og.png', 'img/logo.png'] as $a) {
    $origen = __DIR__ . '/assets/' . $a;
    if (is_file($origen)) {
        asegurar_carpeta(dirname($salida . '/' . $a));
        copy($origen, $salida . '/' . $a);
    }
}
escribir_archivo($salida . '/img/logo.svg', logo_svg());
escribir_archivo($salida . '/img/logo-oscuro.svg', logo_svg(true));
escribir_archivo($salida . '/site.webmanifest', json_encode([
    'name' => cfg('sitio_nombre'), 'short_name' => cfg('sitio_nombre'), 'description' => cfg('sitio_lema'), 'lang' => 'es-AR',
    'start_url' => '/', 'display' => 'browser', 'background_color' => '#ffffff', 'theme_color' => '#0b4d36',
    'icons' => [['src' => '/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png'], ['src' => '/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png'],
        ['src' => '/favicon.svg', 'sizes' => 'any', 'type' => 'image/svg+xml']],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

// ---------- Páginas ----------
$manifiesto_ant = leer_json(cfg('datos') . '/manifiesto.json', []);
$manifiesto = [];
$imagenes = [];
$errores = 0;
// El mapa del sitio se arma al final, con los títulos de todas las páginas ya generadas
$orden = $GLOBALS['PUBLICADAS'];
if (isset($orden['/mapa-del-sitio/'])) { $fm = $orden['/mapa-del-sitio/']; unset($orden['/mapa-del-sitio/']); $orden['/mapa-del-sitio/'] = $fm; }
$GLOBALS['TITULOS'] = [];
foreach ($orden as $path => $fecha) {
    $reg = $GLOBALS['PAGINAS'][$path];
    try {
        $GLOBALS['IMGS_PAGINA'] = [];
        $p = call_user_func($reg['fn']);
        $p['path'] = $path;
        $p['publicada'] = $fecha;
        escribir_archivo($salida . $path . 'index.html', pagina_html($p));
        $GLOBALS['TITULOS'][$path] = $p['h1'] ?? $p['title'];
        $manifiesto[$path] = $reg['seccion'];
        $imagenes[$path] = $GLOBALS['IMGS_PAGINA'];
    } catch (Throwable $ex) {
        $errores++;
        registrar_log("ERROR en $path: " . $ex->getMessage() . ' (' . basename($ex->getFile()) . ':' . $ex->getLine() . ')');
        if (isset($manifiesto_ant[$path])) $manifiesto[$path] = $manifiesto_ant[$path];
    }
}

// Borrar páginas que ya no existen (sólo si su sección se cargó bien en esta corrida)
$secciones_ok = ['inicio' => true];
foreach ($D['ok'] as $k => $v) if ($v) $secciones_ok[$k] = true;
foreach ($manifiesto_ant as $path => $sec) {
    if (isset($manifiesto[$path]) || !isset($secciones_ok[$sec]) || $path === '/') continue;
    @unlink($salida . $path . 'index.html');
    @rmdir($salida . $path);
    registrar_log("Página eliminada: $path");
}
guardar_json(cfg('datos') . '/manifiesto.json', $manifiesto);

// ---------- 404, sitemap, robots, .htaccess, ads.txt ----------
$p404 = ['path' => '/404.html', 'noindex' => true, 'title' => 'Página no encontrada | ' . cfg('sitio_nombre'), 'h1' => 'No encontramos esta página',
    'desc' => 'La página que buscás no existe.', 'cuerpo' => '<p class="intro">Puede que la dirección haya cambiado. Estas son las secciones del sitio:</p><ul class="lista-enlaces">'
        . implode('', array_map(function ($p, $t) { return publicada($p) ? '<li><a href="' . $p . '">' . e($t) . '</a></li>' : ''; }, array_keys(menu_principal()), menu_principal())) . '</ul>'];
escribir_archivo($salida . '/404.html', pagina_html($p404));

$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
foreach ($manifiesto as $path => $sec) {
    $estatica = $sec === 'inicio' && $path !== '/';
    $lastmod = $estatica ? $GLOBALS['PUBLICADAS'][$path] : hoy();
    $img = '';
    foreach (($imagenes[$path] ?? []) as $im) $img .= '<image:image><image:loc>' . e(url_abs($im[0])) . '</image:loc></image:image>';
    $xml .= '<url><loc>' . e(url_abs($path)) . '</loc><lastmod>' . $lastmod . '</lastmod>' . $img . '</url>' . "\n";
}
$xml .= '</urlset>';
escribir_archivo($salida . '/sitemap.xml', $xml);
$llms = '# ' . cfg('sitio_nombre') . "\n\n> " . cfg('llms_resumen') . "\n\nAl citar un dato, incluí la URL de la página y la fecha de actualización que figura en ella.\n\n## Secciones principales\n\n";
foreach (cfg('llms_secciones', []) as $lp => $lt) {
    if (isset($manifiesto[$lp])) $llms .= '- [' . $lt . '](' . url_abs($lp) . ")\n";
}
$llms .= "\n## Todas las páginas\n\n- [Mapa del sitio](" . url_abs('/mapa-del-sitio/') . ")\n- [Sitemap XML](" . url_abs('/sitemap.xml') . ")\n";
escribir_archivo($salida . '/llms.txt', $llms);
escribir_archivo($salida . '/robots.txt', "User-agent: *\nAllow: /\nDisallow: /buscar/?\n\nSitemap: " . url_abs('/sitemap.xml') . "\n");
// Índice del buscador (sólo fichas publicadas)
$idx = [];
foreach ($D['productos'] ?? [] as $pr) if (publicada(path_producto($pr))) $idx[] = [$pr['nombre'], $pr['slug'], $pr['min'], sub_nombre($D, $pr['sub'])];
escribir_archivo($salida . '/buscador.json', json_encode($idx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
escribir_archivo(cfg('datos') . '/ultima-generacion.txt', hoy() . '|' . ($D['meta']['generado'] ?? ''));
if (cfg('adsense_client')) {
    escribir_archivo($salida . '/ads.txt', 'google.com, ' . str_replace('ca-', '', cfg('adsense_client')) . ", DIRECT, f08c47fec0942fa0\n");
}
escribir_htaccess($salida . '/.htaccess');

registrar_log(sprintf('Listo: %d páginas publicadas, %d pendientes de publicar, %d errores, %.1f s', count($manifiesto), $pendientes, $errores, microtime(true) - $t0));
flock($lock, LOCK_UN);

// ---------- Auxiliares ----------

function logo_svg($oscuro = false)
{
    // Isotipo: medidor (velocímetro) con la aguja en la zona "barata"
    $t1 = $oscuro ? '#eef3ee' : '#13201a';
    $t2 = $oscuro ? '#ffd23f' : '#0b6b47';
    $W = 210;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $W . ' 36" width="' . $W . '" height="36"><title>Ofertómetro</title>'
        . '<rect width="36" height="36" rx="9" fill="#0b4d36"/>'
        . '<path d="M7.5 24a10.5 10.5 0 0 1 21 0" fill="none" stroke="#2c7a5a" stroke-width="4" stroke-linecap="round"/>'
        . '<path d="M7.5 24a10.5 10.5 0 0 1 5-8.9" fill="none" stroke="#ffd23f" stroke-width="4" stroke-linecap="round"/>'
        . '<path d="M18 24 11.6 17.4" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><circle cx="18" cy="24" r="2.8" fill="#fff"/>'
        . '<text x="45" y="25.5" font-family="Bricolage Grotesque,system-ui,-apple-system,Segoe UI,Roboto,sans-serif" font-size="21" font-weight="800" letter-spacing="-0.4">'
        . '<tspan fill="' . $t1 . '">Ofertó</tspan><tspan fill="' . $t2 . '">metro</tspan></text></svg>';
}

function escribir_htaccess($ruta)
{
    $host = parse_url(cfg('sitio_url'), PHP_URL_HOST);
    $con_www = strpos($host, 'www.') === 0;
    // Links de referido enmascarados: /ir/clave/ redirige al link real (el código no aparece en el HTML)
    $redir = '';
    foreach (cfg('referidos', []) as $k => $r) {
        if (!empty($r['vence']) && hoy() > $r['vence']) continue;
        if (!empty($r['url']) && preg_match('#^https://[^\s"]+$#', $r['url'])) $redir .= 'RewriteRule ^ir/' . preg_quote($k) . '/?$ ' . str_replace('%', '\\%', $r['url']) . " [R=302,L,NE]\n";
    }
    $bloque = "# BEGIN generador-sitio\n"
        . "Options -Indexes\nDirectoryIndex index.html index.php\nErrorDocument 404 /404.html\n"
        . "<IfModule mod_rewrite.c>\nRewriteEngine On\n"
        . "RewriteCond %{HTTPS} off\nRewriteCond %{HTTP:X-Forwarded-Proto} !https\nRewriteRule ^(.*)$ https://" . $host . "/$1 [R=301,L]\n"
        . ($con_www
            ? "RewriteCond %{HTTP_HOST} !^www\\. [NC]\nRewriteRule ^(.*)$ https://" . $host . "/$1 [R=301,L]\n"
            : "RewriteCond %{HTTP_HOST} ^www\\.(.+)$ [NC]\nRewriteRule ^(.*)$ https://" . $host . "/$1 [R=301,L]\n")
        . $redir
        . "</IfModule>\n"
        . "<IfModule mod_deflate.c>\nAddOutputFilterByType DEFLATE text/html text/css application/javascript image/svg+xml application/json application/xml text/xml text/plain\n</IfModule>\n"
        . "AddType application/manifest+json .webmanifest\nAddType image/x-icon .ico\n"
        . "<IfModule mod_expires.c>\nExpiresActive On\nExpiresByType text/html \"access plus 5 minutes\"\nExpiresByType application/javascript \"access plus 1 year\"\n"
        . "ExpiresByType image/svg+xml \"access plus 1 day\"\nExpiresByType image/png \"access plus 1 month\"\nExpiresByType image/x-icon \"access plus 1 month\"\nExpiresByType application/manifest+json \"access plus 1 week\"\n</IfModule>\n"
        . "<IfModule mod_headers.c>\n<FilesMatch \"\\.(js)$\">\nHeader set Cache-Control \"public, max-age=31536000, immutable\"\n</FilesMatch>\n<FilesMatch \"\\.(html)$\">\nHeader set Cache-Control \"public, max-age=1800\"\n</FilesMatch>\nHeader always set X-Content-Type-Options \"nosniff\"\nHeader always set Referrer-Policy \"strict-origin-when-cross-origin\"\n</IfModule>\n"
        . "# END generador-sitio\n";
    $actual = is_file($ruta) ? file_get_contents($ruta) : '';
    $actual = preg_replace('/# BEGIN generador-sitio.*?# END generador-sitio\n?/s', '', $actual);
    escribir_archivo($ruta, $bloque . $actual);
}
