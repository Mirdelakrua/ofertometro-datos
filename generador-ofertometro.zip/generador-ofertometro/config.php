<?php
/*
 * CONFIGURACIÓN DE OFERTÓMETRO
 * ----------------------------
 * Los precios llegan a diario desde el repositorio público de datos (ver datos_remoto_url),
 * que arma una tarea automática a partir del dataset SEPA de la Secretaría de Comercio.
 * Las claves privadas, si alguna vez hacen falta, van en config-local.php.
 */
$config = [

    'sitio_nombre' => 'Ofertómetro',
    'logo_resalte' => 'metro',
    'logo_ancho' => 210,
    'sitio_url' => 'https://ofertometro.com.ar',
    'sitio_lema' => 'Comparador de precios de supermercados de Argentina',
    'email_contacto' => 'contacto@ofertometro.com.ar',
    'fuentes_css' => 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=Public+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&family=IBM+Plex+Mono:wght@400;600&display=swap',
    'color_tema' => '#0b4d36',

    // En el servidor el generador vive en /home/USUARIO/generador-ofertometro y escribe en /home/USUARIO/ofertometro.com.ar
    'salida' => dirname(__DIR__) . '/ofertometro.com.ar',
    'datos' => __DIR__ . '/datos',

    // Publicación gradual: lo principal sale el primer día, las fichas de producto de a poco
    'paginas_nuevas_por_dia' => 60,

    'adsense_client' => '',
    'adsense_slots' => ['arriba' => '', 'medio' => '', 'abajo' => ''],
    'ga4_id' => '',
    'google_site_verification' => '',

    // Datos diarios (JSON públicos generados por la tarea automática)
    'datos_remoto_url' => 'https://raw.githubusercontent.com/Mirdelakrua/ofertometro-datos/main/',
    'datos_cada_horas' => 2,

    // Cadenas que se muestran en rankings (las demás aparecen en las fichas pero no compiten)
    'ranking_min_sucursales' => 10,
    'ranking_min_productos' => 300,

    'menu' => [
        '/supermercado-mas-barato/' => 'Más barato',
        '/canasta-basica-supermercado/' => 'Canasta',
        '/precios/' => 'Precios',
        '/ofertas/' => 'Ofertas',
        '/supermercados/' => 'Supermercados',
    ],
    'menu_herramientas' => [
        '/buscar/' => 'Buscar un producto',
        '/supermercado-mas-barato/' => 'Supermercado más barato hoy',
        '/canasta-basica-supermercado/' => 'Canasta de supermercado',
        '/ofertas/' => 'Ofertas de la semana',
    ],
    'aviso_legal' => 'Ofertómetro es un comparador <strong>independiente</strong>. Los precios salen de lo que las cadenas informan a diario al programa oficial Precios Claros (SEPA) y pueden variar por sucursal, día o medio de pago: confirmá en la góndola o en la web de la cadena.',
    'pie_legal' => 'Comparador independiente. No vendemos productos ni representamos a ninguna cadena. Las marcas pertenecen a sus dueños.',
    'pie_datos' => 'Datos: SEPA – Precios Claros, Secretaría de Comercio de la Nación (datos.produccion.gob.ar), licencia CC-BY 4.0.',
    'llms_resumen' => 'Comparador argentino e independiente de precios de supermercado: precio de cada producto en las principales cadenas (Coto, Carrefour, Día, Jumbo, Disco, Vea, ChangoMás, La Anónima, Cooperativa Obrera y más), ranking del supermercado más barato por provincia, canasta y ofertas. Datos diarios del SEPA (Precios Claros).',
    'llms_secciones' => [
        '/supermercado-mas-barato/' => 'Cuál es el supermercado más barato hoy', '/canasta-basica-supermercado/' => 'Canasta de supermercado por cadena',
        '/precios/' => 'Precios de supermercado por categoría', '/ofertas/' => 'Ofertas y promociones de supermercados', '/supermercados/' => 'Cadenas de supermercados',
    ],

    'zona_horaria' => 'America/Argentina/Buenos_Aires',
    'modo_prueba' => '',
];

$local = __DIR__ . '/config-local.php';
return is_file($local) ? array_replace($config, (array) require $local) : $config;
